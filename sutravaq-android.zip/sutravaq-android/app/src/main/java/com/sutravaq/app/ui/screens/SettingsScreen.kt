package com.sutravaq.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sutravaq.app.R
import com.sutravaq.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    displayName: String,
    aboutText: String,
    onBackClick: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onNavigateToPrivacy: () -> Unit,
    onNavigateToAbout: () -> Unit
) {
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", color = MaterialTheme.colorScheme.onBackground) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Card Shortcut
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onNavigateToProfile),
                    colors = CardDefaults.cardColors(containerColor = BrandCardDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(BrandSurfaceVariantDark),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = displayName.take(2).uppercase(),
                                style = MaterialTheme.typography.titleLarge,
                                color = CyberCyan
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = displayName, style = MaterialTheme.typography.titleMedium, color = BrandWhite)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(text = aboutText, style = MaterialTheme.typography.bodyMedium, color = BrandSlateText)
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = BrandSlateText)
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = BrandCardDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column {
                        SettingItem(Icons.Default.Security, "Privacy and Security", "Public discovery, relay settings, encryption") {
                            onNavigateToPrivacy()
                        }
                        HorizontalDivider(color = BrandBorderDark)
                        SettingItem(Icons.Default.Notifications, "Notifications", "Mesh message tones, vibration, priority alerts") {
                            Toast.makeText(context, "Notifications active", Toast.LENGTH_SHORT).show()
                        }
                        HorizontalDivider(color = BrandBorderDark)
                        SettingItem(Icons.Default.Storage, "Storage and Data", "Offline message cache, media fragmentation quotas") {
                            Toast.makeText(context, "Encrypted local storage: 1.4 MB", Toast.LENGTH_SHORT).show()
                        }
                        HorizontalDivider(color = BrandBorderDark)
                        SettingItem(Icons.Default.Info, "About SUTRAVAQ", "App version, mesh network disclosures, licenses") {
                            onNavigateToAbout()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium, color = BrandWhite)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, style = MaterialTheme.typography.labelSmall, color = BrandSlateText)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = BrandSlateText)
    }
}
