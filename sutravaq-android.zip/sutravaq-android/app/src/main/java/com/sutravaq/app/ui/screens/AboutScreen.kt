package com.sutravaq.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sutravaq.app.R
import com.sutravaq.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBackClick: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("About SUTRAVAQ", color = MaterialTheme.colorScheme.onBackground) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            item {
                // Official Brand Logo (Single source of truth)
                Image(
                    painter = painterResource(id = R.drawable.ic_sutravaq_splash),
                    contentDescription = "Official SUTRAVAQ Logo",
                    modifier = Modifier
                        .size(110.dp)
                        .clip(CircleShape)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "SUTRAVAQ",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.sp
                    ),
                    color = BrandWhite
                )

                Text(
                    text = "Connect Without Internet",
                    style = MaterialTheme.typography.titleMedium,
                    color = CyberCyan
                )

                Text(
                    text = "Version 1.0.0 (Decentralized Mesh Build)",
                    style = MaterialTheme.typography.labelSmall,
                    color = BrandSlateText
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = BrandCardDark),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Core Architecture",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = CyberCyan
                        )
                        Text(
                            text = "SUTRAVAQ is a decentralized, offline peer-to-peer messaging and voice platform. It requires no SIM card, mobile data, cellular network, cloud messaging servers, or central routing infrastructure.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BrandSlateText
                        )
                        Text(
                            text = "Instead, nearby participating Android smartphones self-organize into an encrypted multi-hop Bluetooth Low Energy mesh network (Phone A → Phone B → Phone C → Phone D).",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BrandSlateText
                        )
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = BrandCardDark),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Range & Hardware Disclosure",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = CyberCyan
                        )
                        Text(
                            text = "Total communication range is not unlimited: it is dynamically extended by participating relay phones acting as mesh nodes. Direct Bluetooth radio reach is typically 10 to 30 meters per hop.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BrandSlateText
                        )
                        Text(
                            text = "Real-time duplex voice calls operate across direct 1-hop connections. Multi-hop voice communication is delivered via asynchronous encrypted Voice Notes with store-and-forward routing.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BrandSlateText
                        )
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = BrandCardDark),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = ActiveEmerald)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Audited Cryptography",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = ActiveEmerald
                            )
                        }
                        Text(
                            text = "• Key Agreement: ECDH over NIST P-256 (secp256r1)\n• Payload Cipher: AES-256-GCM (96-bit unique IV, 128-bit tag)\n• Key Derivation: SHA-256 HKDF (RFC 5869)\n• Packet Integrity: CRC32 + HMAC-SHA256\n• Relay Zero-Knowledge: Intermediate relay nodes cannot decrypt message content",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BrandSlateText
                        )
                    }
                }
            }
        }
    }
}
