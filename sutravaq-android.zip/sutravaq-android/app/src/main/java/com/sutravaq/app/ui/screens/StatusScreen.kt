package com.sutravaq.app.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sutravaq.app.data.db.entity.StatusEntity
import com.sutravaq.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun StatusScreen(
    myStatuses: List<StatusEntity>,
    recentStatuses: List<StatusEntity>,
    onCreateStatusClick: () -> Unit,
    onStatusClick: (StatusEntity) -> Unit,
    onDeleteStatus: (statusId: String) -> Unit
) {
    val context = LocalContext.current
    var viewingStatus by remember { mutableStateOf<StatusEntity?>(null) }

    Scaffold(
        floatingActionButton = {
            Column(horizontalAlignment = Alignment.End) {
                SmallFloatingActionButton(
                    onClick = onCreateStatusClick,
                    containerColor = BrandSurfaceVariantDark,
                    contentColor = CyberCyan,
                    modifier = Modifier.padding(bottom = 12.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = "Text Status")
                }
                FloatingActionButton(
                    onClick = onCreateStatusClick,
                    containerColor = CyberCyan,
                    contentColor = BrandBlack
                ) {
                    Icon(Icons.Default.CameraAlt, contentDescription = "Photo Status")
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // My Status Section
            item {
                Text(
                    text = "My Status",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = CyberCyan
                )
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            if (myStatuses.isNotEmpty()) viewingStatus = myStatuses.first()
                            else onCreateStatusClick()
                        },
                    colors = CardDefaults.cardColors(containerColor = BrandCardDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(14.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(BrandSurfaceVariantDark),
                            contentAlignment = Alignment.Center
                        ) {
                            if (myStatuses.isNotEmpty()) {
                                Icon(Icons.Default.DonutLarge, contentDescription = null, tint = CyberCyan)
                            } else {
                                Icon(Icons.Default.Add, contentDescription = null, tint = CyberCyan)
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "My Status",
                                style = MaterialTheme.typography.titleMedium,
                                color = BrandWhite
                            )
                            Text(
                                text = if (myStatuses.isNotEmpty())
                                    "${myStatuses.size} active (expires in 24h) • ${myStatuses.first().viewCount} views"
                                else
                                    "Tap to add private status update",
                                style = MaterialTheme.typography.bodyMedium,
                                color = BrandSlateText
                            )
                        }

                        if (myStatuses.isNotEmpty()) {
                            IconButton(onClick = { onDeleteStatus(myStatuses.first().statusId) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ErrorRed)
                            }
                        }
                    }
                }
            }

            // Recent Updates Section
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Recent Updates (${recentStatuses.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = CyberCyan
                )
            }

            if (recentStatuses.isEmpty()) {
                item {
                    Text(
                        text = "No recent status updates from your contacts. Statuses propagate privately through the offline mesh.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = BrandSlateText,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                }
            } else {
                items(recentStatuses, key = { it.statusId }) { status ->
                    StatusCard(
                        status = status,
                        onClick = { viewingStatus = status }
                    )
                }
            }
        }
    }

    // Status Viewer Dialog
    viewingStatus?.let { status ->
        StatusViewDialog(
            status = status,
            onDismiss = { viewingStatus = null }
        )
    }
}

@Composable
fun StatusCard(
    status: StatusEntity,
    onClick: () -> Unit
) {
    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val timeStr = timeFormat.format(Date(status.timestamp))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = BrandCardDark),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(BrandSurfaceVariantDark),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = status.authorName.take(2).uppercase(),
                    style = MaterialTheme.typography.titleMedium,
                    color = if (status.isViewedByMe) BrandSlateText else CyberCyan
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = status.authorName,
                    style = MaterialTheme.typography.titleMedium,
                    color = BrandWhite
                )
                Text(
                    text = status.contentText.ifBlank { "[${status.mediaType} Status]" },
                    style = MaterialTheme.typography.bodyMedium,
                    color = BrandSlateText,
                    maxLines = 1
                )
                Text(
                    text = "Today at $timeStr • Encrypted 24h",
                    style = MaterialTheme.typography.labelSmall,
                    color = BrandMutedText
                )
            }
        }
    }
}

@Composable
fun StatusViewDialog(
    status: StatusEntity,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.DonutLarge, contentDescription = null, tint = CyberCyan)
                Spacer(modifier = Modifier.width(8.dp))
                Text(status.authorName, color = BrandWhite)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(BrandObsidian),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = status.contentText.ifBlank { "Encrypted ${status.mediaType} Content" },
                        style = MaterialTheme.typography.headlineMedium,
                        color = BrandWhite,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.padding(16.dp)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Audience: ${status.privacyTier} • Offline Mesh Dispatched",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberCyan
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = BrandBlack)
            ) {
                Text("Close")
            }
        },
        containerColor = BrandSurfaceDark
    )
}
