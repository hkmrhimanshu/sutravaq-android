package com.sutravaq.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Chat conversation summary representing a thread with a contact or group.
 */
@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey
    val peerId: String,                  // SUTRAVAQ Node ID
    val peerDisplayName: String,
    val lastMessageText: String,
    val lastMessageTimestamp: Long,
    val unreadCount: Int = 0,
    val isPinned: Boolean = false,
    val isBlocked: Boolean = false,
    val avatarUri: String? = null,
    val lastMessageStatus: String = "DELIVERED" // PENDING, SENT, DELIVERED, READ
)

/**
 * Individual chat message in a conversation.
 */
@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey
    val messageId: String,               // UUID
    val conversationId: String,          // peerId
    val senderId: String,
    val recipientId: String,
    val content: String,                 // Plaintext content (decrypted locally)
    val mediaType: String = "TEXT",       // TEXT, IMAGE, VOICE, GIF, FILE
    val mediaUri: String? = null,
    val mediaSize: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "SENT",          // QUEUED_OFFLINE, TRANSMITTING_MESH, DELIVERED, READ, FAILED
    val isFromMe: Boolean = true,
    val replyToMessageId: String? = null,
    val replyToSnippet: String? = null,
    val hopCount: Int = 1,
    val transferProgress: Float = 1.0f
)

/**
 * Contact record representing a discovered or QR-paired user.
 */
@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey
    val userId: String,                  // SUTRAVAQ Node ID
    val displayName: String,
    val aboutText: String = "Using SUTRAVAQ mesh",
    val publicKeyHex: String,
    val isPublic: Boolean = true,
    val isFriend: Boolean = false,
    val isBlocked: Boolean = false,
    val trustStatus: String = "UNVERIFIED", // UNVERIFIED, PENDING_APPROVAL, VERIFIED_QR
    val lastSeenTimestamp: Long = System.currentTimeMillis(),
    val directHopDistance: Int = 1,
    val isNearby: Boolean = true
)

/**
 * 24-hour private ephemeral status update.
 */
@Entity(tableName = "statuses")
data class StatusEntity(
    @PrimaryKey
    val statusId: String,                // UUID
    val authorId: String,
    val authorName: String,
    val mediaType: String = "TEXT",       // TEXT, IMAGE, GIF, VIDEO
    val contentText: String = "",
    val mediaUri: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + 24 * 60 * 60 * 1000L,
    val privacyTier: String = "CONTACTS",  // CONTACTS, SELECTED, NOBODY
    val viewCount: Int = 0,
    val isViewedByMe: Boolean = false,
    val isFromMe: Boolean = false
)

/**
 * Call log history entry.
 */
@Entity(tableName = "call_logs")
data class CallLogEntity(
    @PrimaryKey
    val callId: String,                  // UUID
    val peerId: String,
    val peerName: String,
    val callType: String,                // INCOMING, OUTGOING, MISSED
    val callMode: String = "DIRECT_BLUETOOTH", // DIRECT_BLUETOOTH, VOICE_NOTE_RELAY
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Int = 0
)

/**
 * Store-and-Forward packet queue for messages waiting for a route or node discovery.
 */
@Entity(tableName = "queued_packets")
data class QueuedPacketEntity(
    @PrimaryKey
    val packetId: String,
    val destinationId: String,
    val rawPacketBytes: ByteArray,
    val retryCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val ttl: Int = 5,
    val priority: Int = 0                // Higher priority sent first
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is QueuedPacketEntity) return false
        return packetId == other.packetId &&
                destinationId == other.destinationId &&
                rawPacketBytes.contentEquals(other.rawPacketBytes)
    }

    override fun hashCode(): Int {
        var result = packetId.hashCode()
        result = 31 * result + destinationId.hashCode()
        result = 31 * result + rawPacketBytes.contentHashCode()
        return result
    }
}
