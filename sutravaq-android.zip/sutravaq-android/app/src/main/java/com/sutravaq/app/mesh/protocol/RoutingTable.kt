package com.sutravaq.app.mesh.protocol

import java.util.concurrent.ConcurrentHashMap

/**
 * In-memory routing table for SUTRAVAQ Bluetooth Mesh Network.
 *
 * Tracks direct 1-hop BLE neighbors and multi-hop reachable destinations,
 * with metric-based path selection (minimum hops, highest RSSI, and battery constraint).
 */
class RoutingTable(private val myNodeId: String) {

    data class RouteEntry(
        val destinationNodeId: String,
        val nextHopAddress: String, // Bluetooth MAC or direct peer node ID
        val hopCount: Int,          // 1 = direct 1-hop neighbor, 2+ = multi-hop
        val rssi: Int,              // Received Signal Strength Indication (dBm)
        val lastSeenMs: Long = System.currentTimeMillis(),
        val isDirectNeighbor: Boolean = (hopCount == 1),
        val isLowBatteryRelay: Boolean = false
    )

    private val routes = ConcurrentHashMap<String, RouteEntry>()

    /**
     * Updates or creates a route entry.
     * Prefers paths with lower hop counts; if hop counts are equal, prefers higher RSSI.
     */
    fun updateRoute(
        destinationNodeId: String,
        nextHopAddress: String,
        hopCount: Int,
        rssi: Int,
        isLowBattery: Boolean = false
    ): Boolean {
        if (destinationNodeId.equals(myNodeId, ignoreCase = true)) return false

        val existing = routes[destinationNodeId]
        val now = System.currentTimeMillis()

        if (existing == null) {
            routes[destinationNodeId] = RouteEntry(
                destinationNodeId = destinationNodeId,
                nextHopAddress = nextHopAddress,
                hopCount = hopCount,
                rssi = rssi,
                lastSeenMs = now,
                isLowBatteryRelay = isLowBattery
            )
            return true
        }

        // Compare route quality:
        // 1. If new route has strictly fewer hops, accept.
        // 2. If same hops, accept if newer or better RSSI.
        val shouldUpdate = when {
            hopCount < existing.hopCount -> true
            hopCount == existing.hopCount && rssi > existing.rssi -> true
            (now - existing.lastSeenMs) > ROUTE_REFRESH_INTERVAL_MS -> true
            else -> false
        }

        if (shouldUpdate) {
            routes[destinationNodeId] = existing.copy(
                nextHopAddress = nextHopAddress,
                hopCount = hopCount,
                rssi = rssi,
                lastSeenMs = now,
                isLowBatteryRelay = isLowBattery
            )
            return true
        }

        return false
    }

    /**
     * Finds the best next-hop address for a given destination.
     */
    fun getNextHop(destinationNodeId: String): String? {
        val route = routes[destinationNodeId] ?: return null
        val now = System.currentTimeMillis()
        if (now - route.lastSeenMs > ROUTE_EXPIRATION_MS) {
            routes.remove(destinationNodeId)
            return null
        }
        return route.nextHopAddress
    }

    /**
     * Returns true if destination is known and route is active.
     */
    fun isReachable(destinationNodeId: String): Boolean {
        return getNextHop(destinationNodeId) != null
    }

    /**
     * Returns list of all active direct 1-hop neighbors.
     */
    fun getDirectNeighbors(): List<RouteEntry> {
        val now = System.currentTimeMillis()
        return routes.values.filter {
            it.isDirectNeighbor && (now - it.lastSeenMs) <= ROUTE_EXPIRATION_MS
        }
    }

    /**
     * Returns list of all active reachable peer routes (direct + multi-hop).
     */
    fun getAllActiveRoutes(): List<RouteEntry> {
        val now = System.currentTimeMillis()
        return routes.values.filter {
            (now - it.lastSeenMs) <= ROUTE_EXPIRATION_MS
        }
    }

    /**
     * Removes stale routes that haven't been updated within expiration window.
     */
    fun pruneStaleRoutes() {
        val now = System.currentTimeMillis()
        routes.entries.removeIf { (now - it.value.lastSeenMs) > ROUTE_EXPIRATION_MS }
    }

    fun removeRoute(destinationNodeId: String) {
        routes.remove(destinationNodeId)
    }

    fun clear() {
        routes.clear()
    }

    companion object {
        const val ROUTE_REFRESH_INTERVAL_MS = 30_000L // 30 seconds
        const val ROUTE_EXPIRATION_MS = 180_000L      // 3 minutes without beacon
    }
}
