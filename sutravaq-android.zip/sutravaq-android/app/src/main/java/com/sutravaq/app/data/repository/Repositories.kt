package com.sutravaq.app.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.sutravaq.app.crypto.KeyManager
import com.sutravaq.app.data.db.SutravaqDatabase
import com.sutravaq.app.data.db.entity.*
import com.sutravaq.app.mesh.ble.MeshEngine
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class ChatRepository(
    private val database: SutravaqDatabase,
    private val meshEngine: MeshEngine
) {
    fun getAllConversations(): Flow<List<ConversationEntity>> =
        database.conversationDao().getAllConversations()

    fun getMessagesForConversation(conversationId: String): Flow<List<MessageEntity>> =
        database.messageDao().getMessagesForConversation(conversationId)

    suspend fun sendMessage(
        conversationId: String,
        recipientNodeId: String,
        content: String,
        mediaType: String = "TEXT",
        replyToMessageId: String? = null
    ) {
        meshEngine.sendChatMessage(conversationId, recipientNodeId, content, mediaType, replyToMessageId)
    }

    suspend fun deleteMessage(messageId: String) {
        database.messageDao().deleteMessage(messageId)
    }

    suspend fun clearConversation(conversationId: String) {
        database.messageDao().clearConversation(conversationId)
        database.conversationDao().delete(conversationId)
    }

    suspend fun markAsRead(peerId: String) {
        database.conversationDao().markAsRead(peerId)
    }
}

class ContactRepository(
    private val database: SutravaqDatabase,
    private val keyManager: KeyManager
) {
    fun getAllContacts(): Flow<List<ContactEntity>> = database.contactDao().getAllContacts()
    fun getNearbyDiscoverableContacts(): Flow<List<ContactEntity>> =
        database.contactDao().getNearbyDiscoverableContacts()
    fun getBlockedContacts(): Flow<List<ContactEntity>> = database.contactDao().getBlockedContacts()

    suspend fun addOrUpdateContact(contact: ContactEntity) {
        database.contactDao().insertOrUpdate(contact)
        if (contact.publicKeyHex.isNotEmpty()) {
            keyManager.storePeerPublicKey(
                contact.userId,
                com.sutravaq.app.crypto.CryptoEngine.hexToBytes(contact.publicKeyHex)
            )
        }
    }

    suspend fun setBlocked(userId: String, isBlocked: Boolean) {
        database.contactDao().setBlocked(userId, isBlocked)
        database.conversationDao().setBlocked(userId, isBlocked)
    }
}

class StatusRepository(
    private val database: SutravaqDatabase,
    private val meshEngine: MeshEngine,
    private val keyManager: KeyManager
) {
    fun getActiveStatuses(): Flow<List<StatusEntity>> =
        database.statusDao().getActiveStatuses(System.currentTimeMillis())

    fun getMyStatuses(): Flow<List<StatusEntity>> =
        database.statusDao().getMyStatuses(keyManager.myNodeId, System.currentTimeMillis())

    suspend fun postStatus(
        contentText: String,
        mediaType: String = "TEXT",
        privacyTier: String = "CONTACTS"
    ) {
        val statusId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val status = StatusEntity(
            statusId = statusId,
            authorId = keyManager.myNodeId,
            authorName = "You",
            mediaType = mediaType,
            contentText = contentText,
            timestamp = now,
            expiresAt = now + 24 * 60 * 60 * 1000L,
            privacyTier = privacyTier,
            isFromMe = true
        )
        database.statusDao().insertStatus(status)
        meshEngine.broadcastStatus(statusId, contentText, mediaType, privacyTier)
    }

    suspend fun markViewed(statusId: String) {
        database.statusDao().markStatusViewed(statusId)
    }

    suspend fun deleteStatus(statusId: String) {
        database.statusDao().deleteStatus(statusId)
    }
}

class CallRepository(
    private val database: SutravaqDatabase
) {
    fun getAllCallLogs(): Flow<List<CallLogEntity>> = database.callLogDao().getAllCallLogs()

    suspend fun logCall(
        peerId: String,
        peerName: String,
        callType: String,
        callMode: String,
        durationSeconds: Int
    ) {
        val callLog = CallLogEntity(
            callId = UUID.randomUUID().toString(),
            peerId = peerId,
            peerName = peerName,
            callType = callType,
            callMode = callMode,
            durationSeconds = durationSeconds
        )
        database.callLogDao().insertCallLog(callLog)
    }

    suspend fun clearHistory() {
        database.callLogDao().clearAllCallLogs()
    }
}

class SettingsRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("sutravaq_user_settings", Context.MODE_PRIVATE)

    var displayName: String
        get() = prefs.getString("display_name", "SUTRAVAQ User") ?: "SUTRAVAQ User"
        set(value) = prefs.edit().putString("display_name", value).apply()

    var aboutText: String
        get() = prefs.getString("about_text", "Connecting without Internet via SUTRAVAQ mesh") ?: ""
        set(value) = prefs.edit().putString("about_text", value).apply()

    var isPublicDiscoveryEnabled: Boolean
        get() = prefs.getBoolean("public_discovery", true)
        set(value) = prefs.edit().putBoolean("public_discovery", value).apply()

    var isRelayParticipationEnabled: Boolean
        get() = prefs.getBoolean("relay_participation", true)
        set(value) = prefs.edit().putBoolean("relay_participation", value).apply()

    var isReadReceiptsEnabled: Boolean
        get() = prefs.getBoolean("read_receipts", true)
        set(value) = prefs.edit().putBoolean("read_receipts", value).apply()
}
