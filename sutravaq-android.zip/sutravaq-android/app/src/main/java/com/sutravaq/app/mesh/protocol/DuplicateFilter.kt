package com.sutravaq.app.mesh.protocol

import java.util.LinkedHashMap

/**
 * Duplicate Packet Suppression Filter.
 *
 * Prevents infinite broadcast storming and duplicate packet processing across
 * the multi-hop Bluetooth mesh network using a thread-safe LRU cache with
 * time-to-live expiration.
 */
class DuplicateFilter(
    private val maxCapacity: Int = 5000,
    private val expirationMs: Long = 60 * 60 * 1000L // 1 hour
) {
    private class CacheEntry(val timestamp: Long)

    private val cache = object : LinkedHashMap<String, CacheEntry>(maxCapacity, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CacheEntry>?): Boolean {
            return size > maxCapacity
        }
    }

    /**
     * Checks if a packet ID has already been seen.
     * If unseen, records it and returns false (not duplicate).
     * If seen, returns true (is duplicate, should drop).
     */
    @Synchronized
    fun isDuplicateAndMark(packetId: String): Boolean {
        val now = System.currentTimeMillis()
        val entry = cache[packetId]

        if (entry != null && (now - entry.timestamp) < expirationMs) {
            return true // Duplicate within valid window
        }

        // Record new seen packet
        cache[packetId] = CacheEntry(now)
        return false
    }

    /**
     * Checks if packet is known without marking it.
     */
    @Synchronized
    fun contains(packetId: String): Boolean {
        val now = System.currentTimeMillis()
        val entry = cache[packetId] ?: return false
        return (now - entry.timestamp) < expirationMs
    }

    /**
     * Clears all entries.
     */
    @Synchronized
    fun clear() {
        cache.clear()
    }
}
