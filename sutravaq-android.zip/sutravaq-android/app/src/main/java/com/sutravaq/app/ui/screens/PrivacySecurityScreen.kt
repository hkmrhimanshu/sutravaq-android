package com.sutravaq.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sutravaq.app.data.repository.SettingsRepository
import com.sutravaq.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacySecurityScreen(
    settingsRepository: SettingsRepository,
    onBackClick: () -> Unit,
    onResetKeysClick: () -> Unit
) {
    val context = LocalContext.current

    var publicDiscovery by remember { mutableStateOf(settingsRepository.isPublicDiscoveryEnabled) }
    var relayParticipation by remember { mutableStateOf(settingsRepository.isRelayParticipationEnabled) }
    var readReceipts by remember { mutableStateOf(settingsRepository.isReadReceiptsEnabled) }
    var showWipeConfirmDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Privacy and Security", color = MaterialTheme.colorScheme.onBackground) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Privacy Category
            item {
                Text(
                    text = "Privacy Controls",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = CyberCyan
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = BrandCardDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column {
                        SettingToggleItem(
                            title = "Public Mesh Discovery",
                            subtitle = "Allow nearby consenting SUTRAVAQ devices to discover your display name",
                            checked = publicDiscovery,
                            onCheckedChange = {
                                publicDiscovery = it
                                settingsRepository.isPublicDiscoveryEnabled = it
                            }
                        )
                        HorizontalDivider(color = BrandBorderDark)
                        SettingToggleItem(
                            title = "Read Receipts",
                            subtitle = "Send and receive double cyan ticks when messages are read",
                            checked = readReceipts,
                            onCheckedChange = {
                                readReceipts = it
                                settingsRepository.isReadReceiptsEnabled = it
                            }
                        )
                        HorizontalDivider(color = BrandBorderDark)
                        SettingNavigationItem(
                            title = "Status Audience",
                            subtitle = "Default: Approved Contacts Only",
                            icon = Icons.Default.Visibility
                        ) {
                            Toast.makeText(context, "Status audience configured", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }

            // Mesh Network Category
            item {
                Text(
                    text = "Bluetooth Mesh Networking",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = CyberCyan
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = BrandCardDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column {
                        SettingToggleItem(
                            title = "Participate in Mesh Relaying",
                            subtitle = "Relay encrypted packets for others. Automatic pause when battery < 15%",
                            checked = relayParticipation,
                            onCheckedChange = {
                                relayParticipation = it
                                settingsRepository.isRelayParticipationEnabled = it
                            }
                        )
                        HorizontalDivider(color = BrandBorderDark)
                        SettingNavigationItem(
                            title = "Network Diagnostics",
                            subtitle = "GATT MTU 512 • BLE Advertising Active",
                            icon = Icons.Default.SignalCellularAlt
                        ) {
                            Toast.makeText(context, "All BLE Mesh engines operational", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }

            // Cryptographic Security Category
            item {
                Text(
                    text = "Cryptographic Security",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = CyberCyan
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = BrandCardDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column {
                        SettingNavigationItem(
                            title = "Encryption Standard",
                            subtitle = "AES-256-GCM • ECDH NIST P-256 • HKDF-SHA256",
                            icon = Icons.Default.Lock
                        ) {}
                        HorizontalDivider(color = BrandBorderDark)
                        SettingNavigationItem(
                            title = "Rotate Identity Keypair",
                            subtitle = "Generate fresh cryptographic keys and node ID",
                            icon = Icons.Default.VpnKey
                        ) {
                            onResetKeysClick()
                            Toast.makeText(context, "Identity keys rotated", Toast.LENGTH_SHORT).show()
                        }
                        HorizontalDivider(color = BrandBorderDark)
                        SettingNavigationItem(
                            title = "Wipe All Data & Remove Identity",
                            subtitle = "Irrevocably deletes messages, contacts, keys, and mesh logs",
                            icon = Icons.Default.DeleteForever,
                            isDestructive = true
                        ) {
                            showWipeConfirmDialog = true
                        }
                    }
                }
            }
        }
    }

    if (showWipeConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showWipeConfirmDialog = false },
            title = { Text("Wipe All SUTRAVAQ Data?", color = ErrorRed) },
            text = {
                Text(
                    "This will delete all local conversations, encrypted message queues, contacts, and generate a new identity key. You will need to re-pair with your contacts.",
                    color = BrandSlateText
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onResetKeysClick()
                        showWipeConfirmDialog = false
                        Toast.makeText(context, "All data wiped", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed, contentColor = BrandWhite)
                ) {
                    Text("Wipe Data")
                }
            },
            dismissButton = {
                TextButton(onClick = { showWipeConfirmDialog = false }) {
                    Text("Cancel", color = BrandSlateText)
                }
            },
            containerColor = BrandSurfaceDark
        )
    }
}

@Composable
fun SettingToggleItem(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium, color = BrandWhite)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, style = MaterialTheme.typography.labelSmall, color = BrandSlateText)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = BrandBlack,
                checkedTrackColor = CyberCyan
            )
        )
    }
}

@Composable
fun SettingNavigationItem(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isDestructive: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isDestructive) ErrorRed else CyberCyan,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = if (isDestructive) ErrorRed else BrandWhite
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, style = MaterialTheme.typography.labelSmall, color = BrandSlateText)
        }
    }
}
