package com.sutravaq.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = BrandBlack,
    primaryContainer = BrandSurfaceVariantDark,
    onPrimaryContainer = CyberCyanGlow,
    secondary = BrandWhite,
    onSecondary = BrandBlack,
    background = BrandObsidian,
    onBackground = BrandWhite,
    surface = BrandSurfaceDark,
    onSurface = BrandWhite,
    surfaceVariant = BrandSurfaceVariantDark,
    onSurfaceVariant = BrandSlateText,
    outline = BrandBorderDark,
    error = ErrorRed
)

private val LightColorScheme = lightColorScheme(
    primary = BrandBlack,
    onPrimary = BrandWhite,
    primaryContainer = LightSurfaceVariant,
    onPrimaryContainer = BrandBlack,
    secondary = CyberCyan,
    onSecondary = BrandWhite,
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightTextSecondary,
    outline = LightBorder,
    error = ErrorRed
)

@Composable
fun SutravaqTheme(
    darkTheme: Boolean = true, // Default to sleek obsidian dark theme matching official logo
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
