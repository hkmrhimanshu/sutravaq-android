package com.sutravaq.app.mesh.protocol

/**
 * Standard packet types for SUTRAVAQ Bluetooth Mesh Network.
 */
enum class PacketType(val code: Byte) {
    /** Peer discovery beacon / heartbeat containing sender ID and status */
    HELLO(0x01),

    /** Route advertisement advertising reachability of known nodes */
    ROUTE_ADV(0x02),

    /** End-to-end encrypted chat message payload */
    CHAT_MSG(0x03),

    /** Delivery receipt / hop acknowledgement */
    ACK(0x04),

    /** Fragment of large media (photo, voice note, sticker) */
    MEDIA_CHUNK(0x05),

    /** Ephemeral 24-hour encrypted status update */
    STATUS_UPDATE(0x06),

    /** Low-latency real-time voice call frame (direct 1-hop BLE) */
    VOICE_FRAME(0x07),

    /** Private connection request */
    CONNECT_REQ(0x08),

    /** Private connection response */
    CONNECT_RESP(0x09);

    companion object {
        fun fromCode(code: Byte): PacketType = entries.find { it.code == code } ?: CHAT_MSG
    }
}
