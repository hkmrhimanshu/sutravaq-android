package com.sutravaq.app.ui.theme

import androidx.compose.ui.graphics.Color

// Official Brand Palette (Derived from uploaded logo)
val BrandBlack = Color(0xFF000000)
val BrandObsidian = Color(0xFF0B0F19)
val BrandSurfaceDark = Color(0xFF121826)
val BrandSurfaceVariantDark = Color(0xFF1A2234)
val BrandCardDark = Color(0xFF151D2A)
val BrandBorderDark = Color(0xFF263346)

val BrandWhite = Color(0xFFFFFFFF)
val BrandSlateText = Color(0xFF94A3B8)
val BrandMutedText = Color(0xFF64748B)

// Accent and status highlights
val CyberCyan = Color(0xFF00D2FF)
val CyberCyanGlow = Color(0xFF00F0FF)
val ActiveEmerald = Color(0xFF10B981)
val ErrorRed = Color(0xFFEF4444)
val WarningAmber = Color(0xFFF59E0B)

// Light theme colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightCard = Color(0xFFFFFFFF)
val LightBorder = Color(0xFFCBD5E1)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
