package com.sutravaq.app.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sutravaq.app.crypto.KeyManager
import com.sutravaq.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QrScannerScreen(
    keyManager: KeyManager,
    onBackClick: () -> Unit,
    onContactPaired: (peerId: String, peerName: String, peerPubKeyHex: String) -> Unit
) {
    val context = LocalContext.current
    var isTorchOn by remember { mutableStateOf(false) }
    var scannedResult by remember { mutableStateOf<Triple<String, String, ByteArray>?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Scan SUTRAVAQ QR", color = BrandWhite) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = BrandWhite)
                    }
                },
                actions = {
                    IconButton(onClick = { isTorchOn = !isTorchOn }) {
                        Icon(
                            imageVector = if (isTorchOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                            contentDescription = "Flashlight",
                            tint = if (isTorchOn) CyberCyan else BrandWhite
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BrandBlack)
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(BrandBlack),
            contentAlignment = Alignment.Center
        ) {
            // Viewfinder targeting frame
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(260.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .border(3.dp, CyberCyan, RoundedCornerShape(24.dp))
                        .background(BrandSurfaceDark.copy(alpha = 0.4f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = null,
                        tint = CyberCyan.copy(alpha = 0.6f),
                        modifier = Modifier.size(72.dp)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "Align camera with peer's SUTRAVAQ QR code",
                    style = MaterialTheme.typography.bodyMedium,
                    color = BrandSlateText
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Demo Scanner simulation button
                OutlinedButton(
                    onClick = {
                        // Simulate scanning a verified peer
                        val demoPayload = keyManager.generateQrPairingPayload("Alice (Mesh Relay)")
                        val parsed = keyManager.parseQrPairingPayload(demoPayload)
                        scannedResult = parsed
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberCyan),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(CyberCyan))
                ) {
                    Icon(Icons.Default.Camera, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Simulate Camera Detection")
                }
            }
        }
    }

    // Contact Verification & Pairing Modal Bottom Sheet
    scannedResult?.let { (id, name, pubBytes) ->
        ModalBottomSheet(
            onDismissRequest = { scannedResult = null },
            containerColor = BrandSurfaceDark
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(ActiveEmerald.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = ActiveEmerald, modifier = Modifier.size(36.dp))
                }

                Text(
                    text = "Verified SUTRAVAQ Identity",
                    style = MaterialTheme.typography.headlineMedium,
                    color = BrandWhite
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = BrandSurfaceVariantDark)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "Display Name: $name", style = MaterialTheme.typography.titleMedium, color = BrandWhite)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Node ID: ${id.take(16)}...", style = MaterialTheme.typography.labelSmall, color = CyberCyan)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(text = "ECDH Public Key: Verified NIST P-256", style = MaterialTheme.typography.labelSmall, color = ActiveEmerald)
                    }
                }

                Button(
                    onClick = {
                        val pubHex = com.sutravaq.app.crypto.CryptoEngine.bytesToHex(pubBytes)
                        onContactPaired(id, name, pubHex)
                        scannedResult = null
                        Toast.makeText(context, "Securely paired with $name", Toast.LENGTH_SHORT).show()
                        onBackClick()
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = BrandBlack)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Accept & Add Contact", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}
