package com.sutravaq.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sutravaq.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyProfileScreen(
    nodeId: String,
    initialDisplayName: String,
    initialAboutText: String,
    onSaveProfile: (displayName: String, aboutText: String) -> Unit,
    onBackClick: () -> Unit,
    onOpenQr: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var displayName by remember { mutableStateOf(initialDisplayName) }
    var aboutText by remember { mutableStateOf(initialAboutText) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Profile", color = MaterialTheme.colorScheme.onBackground) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onOpenQr) {
                        Icon(Icons.Default.QrCode, contentDescription = "My QR", tint = CyberCyan)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Large Avatar
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(BrandSurfaceVariantDark),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = displayName.take(2).uppercase(),
                        style = MaterialTheme.typography.headlineLarge,
                        color = CyberCyan
                    )
                }

                OutlinedTextField(
                    value = displayName,
                    onValueChange = { displayName = it },
                    label = { Text("Display Name") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = CyberCyan) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = BrandBorderDark,
                        focusedTextColor = BrandWhite,
                        unfocusedTextColor = BrandWhite
                    )
                )

                OutlinedTextField(
                    value = aboutText,
                    onValueChange = { aboutText = it },
                    label = { Text("About Status") },
                    leadingIcon = { Icon(Icons.Default.Info, contentDescription = null, tint = CyberCyan) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = BrandBorderDark,
                        focusedTextColor = BrandWhite,
                        unfocusedTextColor = BrandWhite
                    )
                )

                // Cryptographic Identity Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = BrandCardDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "SUTRAVAQ Mesh Node ID",
                                style = MaterialTheme.typography.titleMedium,
                                color = BrandWhite
                            )
                            IconButton(onClick = {
                                clipboardManager.setText(AnnotatedString(nodeId))
                                Toast.makeText(context, "Node ID copied", Toast.LENGTH_SHORT).show()
                            }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = CyberCyan)
                            }
                        }
                        Text(
                            text = nodeId,
                            style = MaterialTheme.typography.labelSmall,
                            color = BrandSlateText
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Derived deterministically from your hardware-backed ECDH NIST P-256 public key.",
                            style = MaterialTheme.typography.labelSmall,
                            color = BrandMutedText
                        )
                    }
                }
            }

            Button(
                onClick = {
                    onSaveProfile(displayName, aboutText)
                    Toast.makeText(context, "Profile updated", Toast.LENGTH_SHORT).show()
                    onBackClick()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = BrandBlack)
            ) {
                Text("Save Profile", style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}
