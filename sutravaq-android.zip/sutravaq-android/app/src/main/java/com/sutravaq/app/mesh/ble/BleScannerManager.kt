package com.sutravaq.app.mesh.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.le.*
import android.os.ParcelUuid
import android.util.Log

/**
 * Manages Bluetooth Low Energy (BLE) Scanning for nearby SUTRAVAQ mesh peer nodes.
 */
class BleScannerManager(
    private val bluetoothAdapter: BluetoothAdapter?,
    private val onPeerDiscovered: (device: BluetoothDevice, rssi: Int, nodePrefix: String?) -> Unit
) {
    private var scanner: BluetoothLeScanner? = null
    private var isScanning = false

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            result?.let { handleScanResult(it) }
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>?) {
            results?.forEach { handleScanResult(it) }
        }

        override fun onScanFailed(errorCode: Int) {
            Log.e(TAG, "BLE Scan failed with errorCode: $errorCode")
            isScanning = false
        }
    }

    private fun handleScanResult(result: ScanResult) {
        val device = result.device
        val rssi = result.rssi
        val record = result.scanRecord

        val serviceUuid = ParcelUuid(BleAdvertiserManager.SERVICE_UUID)
        val serviceData = record?.getServiceData(serviceUuid)
        val nodePrefixHex = serviceData?.joinToString("") { "%02X".format(it) }

        onPeerDiscovered(device, rssi, nodePrefixHex)
    }

    @SuppressLint("MissingPermission")
    fun startScanning(lowLatency: Boolean = false) {
        if (isScanning || bluetoothAdapter == null || !bluetoothAdapter.isEnabled) return

        scanner = bluetoothAdapter.bluetoothLeScanner
        if (scanner == null) {
            Log.w(TAG, "BluetoothLeScanner not available.")
            return
        }

        val scanMode = if (lowLatency) {
            ScanSettings.SCAN_MODE_LOW_LATENCY
        } else {
            ScanSettings.SCAN_MODE_BALANCED
        }

        val settings = ScanSettings.Builder()
            .setScanMode(scanMode)
            .setReportDelay(0)
            .build()

        val filter = ScanFilter.Builder()
            .setServiceUuid(ParcelUuid(BleAdvertiserManager.SERVICE_UUID))
            .build()

        try {
            scanner?.startScan(listOf(filter), settings, scanCallback)
            isScanning = true
            Log.d(TAG, "BLE Mesh Scanner started.")
        } catch (e: SecurityException) {
            Log.e(TAG, "Missing Bluetooth permission for scanning", e)
        }
    }

    @SuppressLint("MissingPermission")
    fun stopScanning() {
        if (!isScanning || scanner == null) return
        try {
            scanner?.stopScan(scanCallback)
            isScanning = false
            Log.d(TAG, "BLE Mesh Scanner stopped.")
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException while stopping scanner", e)
        }
    }

    companion object {
        private const val TAG = "BleScannerManager"
    }
}
