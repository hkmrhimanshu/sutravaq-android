package com.sutravaq.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.sutravaq.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateStatusScreen(
    onBackClick: () -> Unit,
    onPostStatus: (text: String, mediaType: String, privacy: String) -> Unit
) {
    val context = LocalContext.current
    var statusText by remember { mutableStateOf("") }
    var selectedMediaType by remember { mutableStateOf("TEXT") }
    var selectedPrivacy by remember { mutableStateOf("CONTACTS") } // CONTACTS, SELECTED, NOBODY

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("New Status", color = MaterialTheme.colorScheme.onBackground) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Status content editor box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(BrandCardDark)
                        .padding(16.dp)
                ) {
                    TextField(
                        value = statusText,
                        onValueChange = { statusText = it },
                        modifier = Modifier.fillMaxSize(),
                        placeholder = {
                            Text(
                                "Type your offline status update...",
                                style = MaterialTheme.typography.headlineMedium,
                                color = BrandSlateText
                            )
                        },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                            unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                            focusedTextColor = BrandWhite,
                            unfocusedTextColor = BrandWhite,
                            focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                            unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent
                        )
                    )
                }

                // Media type selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedMediaType == "TEXT",
                        onClick = { selectedMediaType = "TEXT" },
                        label = { Text("Text") },
                        leadingIcon = { Icon(Icons.Default.TextFields, contentDescription = null) }
                    )
                    FilterChip(
                        selected = selectedMediaType == "PHOTO",
                        onClick = {
                            selectedMediaType = "PHOTO"
                            Toast.makeText(context, "Photo attached from camera/gallery", Toast.LENGTH_SHORT).show()
                        },
                        label = { Text("Photo") },
                        leadingIcon = { Icon(Icons.Default.Image, contentDescription = null) }
                    )
                    FilterChip(
                        selected = selectedMediaType == "GIF",
                        onClick = { selectedMediaType = "GIF" },
                        label = { Text("GIF") },
                        leadingIcon = { Icon(Icons.Default.Animation, contentDescription = null) }
                    )
                }

                // Privacy selector
                Card(
                    colors = CardDefaults.cardColors(containerColor = BrandSurfaceVariantDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Status Privacy",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberCyan
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Only authorized contacts can decrypt your status.",
                            style = MaterialTheme.typography.labelSmall,
                            color = BrandSlateText
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = selectedPrivacy == "CONTACTS",
                                onClick = { selectedPrivacy = "CONTACTS" },
                                colors = RadioButtonDefaults.colors(selectedColor = CyberCyan)
                            )
                            Text("Approved Contacts", color = BrandWhite)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = selectedPrivacy == "SELECTED",
                                onClick = { selectedPrivacy = "SELECTED" },
                                colors = RadioButtonDefaults.colors(selectedColor = CyberCyan)
                            )
                            Text("Selected Friends Only", color = BrandWhite)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = selectedPrivacy == "NOBODY",
                                onClick = { selectedPrivacy = "NOBODY" },
                                colors = RadioButtonDefaults.colors(selectedColor = CyberCyan)
                            )
                            Text("Private (Nobody)", color = BrandWhite)
                        }
                    }
                }
            }

            // Post Button
            Button(
                onClick = {
                    if (statusText.isNotBlank() || selectedMediaType != "TEXT") {
                        onPostStatus(statusText, selectedMediaType, selectedPrivacy)
                        Toast.makeText(context, "Status dispatched to SUTRAVAQ mesh", Toast.LENGTH_SHORT).show()
                        onBackClick()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = BrandBlack)
            ) {
                Icon(Icons.Default.Send, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Publish to Mesh (24h)", style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}
