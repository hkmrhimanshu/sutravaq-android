package com.sutravaq.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sutravaq.app.R
import com.sutravaq.app.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onSplashFinished: () -> Unit) {
    val scale = remember { Animatable(0.85f) }
    val alpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        alpha.animateTo(1f, animationSpec = tween(600, easing = FastOutSlowInEasing))
        scale.animateTo(1.05f, animationSpec = tween(700, easing = FastOutSlowInEasing))
        scale.animateTo(1.0f, animationSpec = tween(400, easing = LinearOutSlowInEasing))
        delay(800)
        onSplashFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BrandBlack),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Official Brand Logo
            Image(
                painter = painterResource(id = R.drawable.ic_sutravaq_splash),
                contentDescription = "SUTRAVAQ Splash Logo",
                modifier = Modifier
                    .size(160.dp)
                    .scale(scale.value)
                    .clip(CircleShape)
            )

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = "SUTRAVAQ",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 3.sp
                ),
                color = BrandWhite
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Connect Without Internet",
                style = MaterialTheme.typography.titleMedium,
                color = CyberCyan
            )
        }

        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 36.dp)
        ) {
            Text(
                text = "DECENTRALIZED BLUETOOTH MESH",
                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp),
                color = BrandSlateText
            )
        }
    }
}
