package com.sutravaq.app.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sutravaq.app.data.db.entity.MessageEntity
import com.sutravaq.app.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatDetailScreen(
    peerId: String,
    peerDisplayName: String,
    messages: List<MessageEntity>,
    onBackClick: () -> Unit,
    onCallClick: () -> Unit,
    onSendMessage: (content: String, mediaType: String, replyToId: String?) -> Unit,
    onDeleteMessage: (messageId: String) -> Unit,
    onBlockContact: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var textInput by remember { mutableStateOf("") }
    var replyingToMessage by remember { mutableStateOf<MessageEntity?>(null) }
    var selectedMessageForMenu by remember { mutableStateOf<MessageEntity?>(null) }
    var showAttachmentMenu by remember { mutableStateOf(false) }
    var isRecordingVoice by remember { mutableStateOf(false) }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(BrandSurfaceVariantDark),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = peerDisplayName.take(2).uppercase(),
                                style = MaterialTheme.typography.titleMedium,
                                color = CyberCyan
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = peerDisplayName,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(ActiveEmerald)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "E2E Encrypted • Mesh Direct",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = BrandSlateText
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onCallClick) {
                        Icon(Icons.Default.Call, contentDescription = "Bluetooth Call", tint = CyberCyan)
                    }
                    IconButton(onClick = {
                        onBlockContact()
                        Toast.makeText(context, "Contact Blocked", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(Icons.Default.Block, contentDescription = "Block Contact")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        bottomBar = {
            Column(modifier = Modifier.background(MaterialTheme.colorScheme.surface)) {
                // Reply Preview Bar
                replyingToMessage?.let { replyMsg ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BrandSurfaceVariantDark)
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (replyMsg.isFromMe) "Replying to yourself" else "Replying to $peerDisplayName",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = CyberCyan
                            )
                            Text(
                                text = replyMsg.content,
                                style = MaterialTheme.typography.bodyMedium,
                                color = BrandSlateText,
                                maxLines = 1
                            )
                        }
                        IconButton(onClick = { replyingToMessage = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Cancel reply", tint = BrandSlateText)
                        }
                    }
                }

                // Chat Input Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { showAttachmentMenu = !showAttachmentMenu }) {
                        Icon(
                            imageVector = Icons.Default.AttachFile,
                            contentDescription = "Attach",
                            tint = CyberCyan
                        )
                    }

                    TextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(24.dp)),
                        placeholder = { Text("Mesh message...", color = BrandSlateText) },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = BrandSurfaceVariantDark,
                            unfocusedContainerColor = BrandSurfaceVariantDark,
                            focusedTextColor = BrandWhite,
                            unfocusedTextColor = BrandWhite,
                            focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                            unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent
                        ),
                        maxLines = 4
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    if (textInput.isNotBlank()) {
                        IconButton(
                            onClick = {
                                onSendMessage(textInput, "TEXT", replyingToMessage?.messageId)
                                textInput = ""
                                replyingToMessage = null
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(CyberCyan)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = BrandBlack)
                        }
                    } else {
                        // Voice note record button
                        IconButton(
                            onClick = {
                                isRecordingVoice = !isRecordingVoice
                                if (!isRecordingVoice) {
                                    // Send simulated voice message
                                    onSendMessage("Voice note (0:08)", "VOICE", replyingToMessage?.messageId)
                                    replyingToMessage = null
                                    Toast.makeText(context, "Voice note sent over mesh", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(if (isRecordingVoice) ErrorRed else BrandSurfaceVariantDark)
                        ) {
                            Icon(
                                Icons.Default.Mic,
                                contentDescription = "Voice note",
                                tint = if (isRecordingVoice) BrandWhite else CyberCyan
                            )
                        }
                    }
                }

                // Attachment Drawer
                AnimatedVisibility(visible = showAttachmentMenu) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BrandSurfaceDark)
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        AttachmentOption(Icons.Default.Image, "Photo") {
                            showAttachmentMenu = false
                            onSendMessage("Photo attachment (Encrypted)", "IMAGE", null)
                            Toast.makeText(context, "Photo fragmented & transmitting via mesh", Toast.LENGTH_SHORT).show()
                        }
                        AttachmentOption(Icons.Default.Mic, "Audio") {
                            showAttachmentMenu = false
                            onSendMessage("Voice Recording (0:15)", "VOICE", null)
                        }
                        AttachmentOption(Icons.Default.InsertDriveFile, "File") {
                            showAttachmentMenu = false
                            onSendMessage("Document: report.pdf (32 KB)", "FILE", null)
                        }
                        AttachmentOption(Icons.Default.EmojiEmotions, "Sticker") {
                            showAttachmentMenu = false
                            onSendMessage("SUTRAVAQ Mesh Sticker", "STICKER", null)
                        }
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(messages, key = { it.messageId }) { msg ->
                MessageBubble(
                    message = msg,
                    onLongClick = { selectedMessageForMenu = msg }
                )
            }
        }
    }

    // Context Menu Bottom Sheet
    selectedMessageForMenu?.let { msg ->
        ModalBottomSheet(
            onDismissRequest = { selectedMessageForMenu = null },
            containerColor = BrandSurfaceVariantDark
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Message Options",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(12.dp))
                ListItem(
                    headlineContent = { Text("Reply") },
                    leadingContent = { Icon(Icons.Default.Reply, contentDescription = null, tint = CyberCyan) },
                    modifier = Modifier.clickable {
                        replyingToMessage = msg
                        selectedMessageForMenu = null
                    }
                )
                ListItem(
                    headlineContent = { Text("Copy Text") },
                    leadingContent = { Icon(Icons.Default.ContentCopy, contentDescription = null, tint = CyberCyan) },
                    modifier = Modifier.clickable {
                        clipboardManager.setText(AnnotatedString(msg.content))
                        selectedMessageForMenu = null
                        Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                    }
                )
                ListItem(
                    headlineContent = { Text("Delete", color = ErrorRed) },
                    leadingContent = { Icon(Icons.Default.Delete, contentDescription = null, tint = ErrorRed) },
                    modifier = Modifier.clickable {
                        onDeleteMessage(msg.messageId)
                        selectedMessageForMenu = null
                    }
                )
            }
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun MessageBubble(
    message: MessageEntity,
    onLongClick: () -> Unit
) {
    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val timeStr = timeFormat.format(Date(message.timestamp))

    val bubbleColor = if (message.isFromMe) BrandCardDark else BrandSurfaceVariantDark
    val alignment = if (message.isFromMe) Alignment.End else Alignment.Start

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalAlignment = alignment
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (message.isFromMe) 16.dp else 2.dp,
                bottomEnd = if (message.isFromMe) 2.dp else 16.dp
            ),
            color = bubbleColor,
            modifier = Modifier
                .widthIn(max = 280.dp)
                .combinedClickable(
                    onClick = {},
                    onLongClick = onLongClick
                )
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                // Media Icon Header if not text
                if (message.mediaType != "TEXT") {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val icon = when (message.mediaType) {
                            "IMAGE" -> Icons.Default.Image
                            "VOICE" -> Icons.Default.Mic
                            "FILE" -> Icons.Default.InsertDriveFile
                            else -> Icons.Default.Attachment
                        }
                        Icon(icon, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(18.dp))
                        Text(
                            text = message.mediaType,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = CyberCyan
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                Text(
                    text = message.content,
                    style = MaterialTheme.typography.bodyLarge,
                    color = BrandWhite
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = timeStr,
                        style = MaterialTheme.typography.labelSmall,
                        color = BrandSlateText
                    )

                    if (message.isFromMe) {
                        when (message.status) {
                            "DELIVERED" -> Icon(
                                Icons.Default.DoneAll,
                                contentDescription = "Delivered",
                                tint = BrandSlateText,
                                modifier = Modifier.size(14.dp)
                            )
                            "READ" -> Icon(
                                Icons.Default.DoneAll,
                                contentDescription = "Read",
                                tint = CyberCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            else -> Icon(
                                Icons.Default.Schedule,
                                contentDescription = "Transmitting",
                                tint = BrandMutedText,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AttachmentOption(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(BrandSurfaceVariantDark),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = CyberCyan)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = BrandSlateText)
    }
}
