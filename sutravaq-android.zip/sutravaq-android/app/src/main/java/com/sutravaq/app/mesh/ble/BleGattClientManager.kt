package com.sutravaq.app.mesh.ble

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.util.Log
import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * Manages outgoing GATT connections and reliable packet writes to peer nodes.
 */
class BleGattClientManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val activeConnections = ConcurrentHashMap<String, BluetoothGatt>()
    private val writeQueues = ConcurrentHashMap<String, ConcurrentLinkedQueue<ByteArray>>()
    private val isWriting = ConcurrentHashMap<String, Boolean>()

    @SuppressLint("MissingPermission")
    fun sendPacket(
        device: BluetoothDevice,
        packetBytes: ByteArray,
        onComplete: (success: Boolean) -> Unit
    ) {
        val address = device.address
        val queue = writeQueues.computeIfAbsent(address) { ConcurrentLinkedQueue() }
        queue.add(packetBytes)

        val existingGatt = activeConnections[address]
        if (existingGatt != null) {
            processNextWrite(address, existingGatt)
            onComplete(true)
        } else {
            connectAndSend(device, onComplete)
        }
    }

    @SuppressLint("MissingPermission")
    private fun connectAndSend(device: BluetoothDevice, onComplete: (success: Boolean) -> Unit) {
        val address = device.address

        val callback = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    Log.d(TAG, "Connected to peer: $address. Requesting MTU 512...")
                    activeConnections[address] = gatt!!
                    gatt.requestMtu(512)
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    Log.d(TAG, "Disconnected from peer: $address")
                    activeConnections.remove(address)
                    isWriting.remove(address)
                    gatt?.close()
                }
            }

            override fun onMtuChanged(gatt: BluetoothGatt?, mtu: Int, status: Int) {
                Log.d(TAG, "MTU changed to $mtu for $address. Discovering services...")
                gatt?.discoverServices()
            }

            override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
                if (status == BluetoothGatt.GATT_SUCCESS && gatt != null) {
                    Log.d(TAG, "Services discovered for $address. Processing write queue...")
                    processNextWrite(address, gatt)
                    onComplete(true)
                } else {
                    Log.e(TAG, "Service discovery failed with status $status")
                    onComplete(false)
                }
            }

            override fun onCharacteristicWrite(
                gatt: BluetoothGatt?,
                characteristic: BluetoothGattCharacteristic?,
                status: Int
            ) {
                isWriting[address] = false
                if (status == BluetoothGatt.GATT_SUCCESS && gatt != null) {
                    processNextWrite(address, gatt)
                } else {
                    Log.w(TAG, "Characteristic write failed for $address, status=$status")
                }
            }
        }

        try {
            val gatt = device.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE)
            activeConnections[address] = gatt
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException connecting to $address", e)
            onComplete(false)
        }
    }

    @SuppressLint("MissingPermission")
    private fun processNextWrite(address: String, gatt: BluetoothGatt) {
        if (isWriting[address] == true) return

        val queue = writeQueues[address] ?: return
        val nextBytes = queue.poll() ?: return

        val service = gatt.getService(BleAdvertiserManager.SERVICE_UUID)
        val char = service?.getCharacteristic(BleAdvertiserManager.CHARACTERISTIC_PACKET_UUID)

        if (char != null) {
            char.value = nextBytes
            char.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            isWriting[address] = true
            val success = gatt.writeCharacteristic(char)
            if (!success) {
                isWriting[address] = false
                Log.w(TAG, "writeCharacteristic returned false for $address")
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnectAll() {
        for ((_, gatt) in activeConnections) {
            try {
                gatt.disconnect()
                gatt.close()
            } catch (e: Exception) {
                Log.e(TAG, "Error closing gatt", e)
            }
        }
        activeConnections.clear()
        writeQueues.clear()
        isWriting.clear()
    }

    companion object {
        private const val TAG = "BleGattClientManager"
    }
}
