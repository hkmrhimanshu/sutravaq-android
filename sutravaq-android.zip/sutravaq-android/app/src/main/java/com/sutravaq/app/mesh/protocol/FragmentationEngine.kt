package com.sutravaq.app.mesh.protocol

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.CRC32

/**
 * Segmentation and Reassembly (SAR) Engine for large media items
 * (photos, voice recordings, attachments) over Bluetooth LE Mesh.
 */
object FragmentationEngine {

    const val DEFAULT_CHUNK_SIZE = 350 // Fits cleanly into negotiated 512-byte BLE MTU

    data class ChunkHeader(
        val transferId: String,
        val totalChunks: Int,
        val chunkIndex: Int,
        val chunkData: ByteArray
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is ChunkHeader) return false
            return transferId == other.transferId &&
                    totalChunks == other.totalChunks &&
                    chunkIndex == other.chunkIndex &&
                    chunkData.contentEquals(other.chunkData)
        }

        override fun hashCode(): Int {
            var result = transferId.hashCode()
            result = 31 * result + totalChunks
            result = 31 * result + chunkIndex
            result = 31 * result + chunkData.contentHashCode()
            return result
        }
    }

    private class IncompleteTransfer(
        val transferId: String,
        val totalChunks: Int,
        val chunks: MutableMap<Int, ByteArray> = ConcurrentHashMap(),
        val createdAt: Long = System.currentTimeMillis()
    )

    // Ongoing incoming transfers: transferId -> IncompleteTransfer
    private val incomingTransfers = ConcurrentHashMap<String, IncompleteTransfer>()

    /**
     * Splits large payload into serialized chunk payloads.
     */
    fun fragmentPayload(
        transferId: String,
        fullData: ByteArray,
        chunkSize: Int = DEFAULT_CHUNK_SIZE
    ): List<ByteArray> {
        val totalChunks = ((fullData.size + chunkSize - 1) / chunkSize).coerceAtLeast(1)
        val chunks = ArrayList<ByteArray>(totalChunks)

        for (index in 0 until totalChunks) {
            val offset = index * chunkSize
            val length = (fullData.size - offset).coerceAtMost(chunkSize)
            val chunkSlice = ByteArray(length)
            System.arraycopy(fullData, offset, chunkSlice, 0, length)

            val header = serializeChunk(transferId, totalChunks, index, chunkSlice)
            chunks.add(header)
        }

        return chunks
    }

    /**
     * Serializes chunk into binary header + data + CRC32.
     * [0..15]  Transfer ID (16 bytes hex)
     * [16..17] Total Chunks (Short)
     * [18..19] Chunk Index (Short)
     * [20..21] Data Length (Short)
     * [22..]   Data bytes
     * [End-4]  CRC32 (Int)
     */
    fun serializeChunk(
        transferId: String,
        totalChunks: Int,
        chunkIndex: Int,
        chunkData: ByteArray
    ): ByteArray {
        val idBytes = transferIdToBytes(transferId)
        val totalSize = 16 + 2 + 2 + 2 + chunkData.size + 4
        val buffer = ByteBuffer.allocate(totalSize).order(ByteOrder.BIG_ENDIAN)

        buffer.put(idBytes)
        buffer.putShort(totalChunks.toShort())
        buffer.putShort(chunkIndex.toShort())
        buffer.putShort(chunkData.size.toShort())
        buffer.put(chunkData)

        val crc = CRC32()
        crc.update(buffer.array(), 0, totalSize - 4)
        buffer.putInt(crc.value.toInt())

        return buffer.array()
    }

    /**
     * Deserializes chunk header and payload.
     */
    fun deserializeChunk(bytes: ByteArray): ChunkHeader? {
        if (bytes.size < 26) return null // Header + CRC minimum

        val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)
        val idBytes = ByteArray(16)
        buffer.get(idBytes)
        val totalChunks = buffer.short.toInt() and 0xFFFF
        val chunkIndex = buffer.short.toInt() and 0xFFFF
        val dataLen = buffer.short.toInt() and 0xFFFF

        if (buffer.remaining() < dataLen + 4) return null
        val data = ByteArray(dataLen)
        buffer.get(data)
        val receivedCrc = buffer.int

        val crc = CRC32()
        crc.update(bytes, 0, bytes.size - 4)
        if (crc.value.toInt() != receivedCrc) {
            return null // CRC mismatch
        }

        val transferId = idBytes.joinToString("") { "%02X".format(it) }
        return ChunkHeader(transferId, totalChunks, chunkIndex, data)
    }

    /**
     * Ingests an incoming chunk.
     * Returns the full reassembled ByteArray if this chunk completes the transfer,
     * or null if more chunks are still pending.
     */
    @Synchronized
    fun ingestChunk(chunkBytes: ByteArray): Pair<ChunkHeader, ByteArray?>? {
        val parsed = deserializeChunk(chunkBytes) ?: return null

        val transfer = incomingTransfers.computeIfAbsent(parsed.transferId) {
            IncompleteTransfer(parsed.transferId, parsed.totalChunks)
        }

        transfer.chunks[parsed.chunkIndex] = parsed.chunkData

        // Check if all chunks have been received
        if (transfer.chunks.size == transfer.totalChunks) {
            // Reconstruct full buffer
            val totalBytes = transfer.chunks.values.sumOf { it.size }
            val reassembled = ByteArray(totalBytes)
            var currentOffset = 0

            for (i in 0 until transfer.totalChunks) {
                val part = transfer.chunks[i] ?: return Pair(parsed, null)
                System.arraycopy(part, 0, reassembled, currentOffset, part.size)
                currentOffset += part.size
            }

            // Cleanup completed transfer
            incomingTransfers.remove(parsed.transferId)
            return Pair(parsed, reassembled)
        }

        return Pair(parsed, null)
    }

    /**
     * Returns list of missing chunk indices for selective retransmission requests.
     */
    fun getMissingChunks(transferId: String): List<Int>? {
        val transfer = incomingTransfers[transferId] ?: return null
        val missing = mutableListOf<Int>()
        for (i in 0 until transfer.totalChunks) {
            if (!transfer.chunks.containsKey(i)) {
                missing.add(i)
            }
        }
        return missing
    }

    /**
     * Prunes expired incomplete transfers older than maxAgeMillis (default 30 mins).
     */
    fun pruneExpired(maxAgeMillis: Long = 30 * 60 * 1000L) {
        val now = System.currentTimeMillis()
        incomingTransfers.entries.removeIf { now - it.value.createdAt > maxAgeMillis }
    }

    private fun transferIdToBytes(id: String): ByteArray {
        val clean = id.replace("-", "").padEnd(32, '0').take(32)
        val data = ByteArray(16)
        for (i in 0 until 16) {
            val index = i * 2
            data[i] = ((Character.digit(clean[index], 16) shl 4) +
                    Character.digit(clean[index + 1], 16)).toByte()
        }
        return data
    }
}
