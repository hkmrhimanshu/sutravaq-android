package com.sutravaq.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sutravaq.app.data.db.entity.CallLogEntity
import com.sutravaq.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun CallsScreen(
    callLogs: List<CallLogEntity>,
    onInitiateCall: (peerId: String, peerName: String) -> Unit,
    onClearHistory: () -> Unit
) {
    var showTechDisclosureDialog by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    // Start call with demo peer or contact
                    onInitiateCall("PEER_NODE_7A82F1", "Nearby Mesh Peer")
                },
                containerColor = CyberCyan,
                contentColor = BrandBlack
            ) {
                Icon(Icons.Default.Call, contentDescription = "New Bluetooth Call")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Technical Architecture & Disclosure Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { showTechDisclosureDialog = true },
                    colors = CardDefaults.cardColors(containerColor = BrandSurfaceVariantDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Direct Bluetooth Voice vs. Mesh Voice Notes",
                                style = MaterialTheme.typography.titleMedium,
                                color = BrandWhite
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Real-time voice calls operate on direct 1-hop BLE. Multi-hop voice uses asynchronous encrypted voice notes.",
                                style = MaterialTheme.typography.labelSmall,
                                color = BrandSlateText
                            )
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Call History (${callLogs.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = CyberCyan
                    )
                    if (callLogs.isNotEmpty()) {
                        TextButton(onClick = onClearHistory) {
                            Text("Clear", color = BrandSlateText)
                        }
                    }
                }
            }

            if (callLogs.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null, tint = BrandMutedText, modifier = Modifier.size(56.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No Call Logs",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Direct Bluetooth voice calls with nearby peers will appear here.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BrandSlateText,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                items(callLogs, key = { it.callId }) { call ->
                    CallLogItem(
                        call = call,
                        onCallAgain = { onInitiateCall(call.peerId, call.peerName) }
                    )
                }
            }
        }
    }

    if (showTechDisclosureDialog) {
        AlertDialog(
            onDismissRequest = { showTechDisclosureDialog = false },
            title = { Text("Offline Voice Architecture", color = BrandWhite) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "1. Direct 1-Hop Voice Calling:",
                        style = MaterialTheme.typography.titleMedium,
                        color = CyberCyan
                    )
                    Text(
                        text = "Direct duplex voice communication operates over point-to-point BLE GATT Audio when devices are within direct radio range (~10-30 meters). No internet or cellular data is ever used.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = BrandSlateText
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "2. Multi-Hop Voice Architecture:",
                        style = MaterialTheme.typography.titleMedium,
                        color = CyberCyan
                    )
                    Text(
                        text = "Bluetooth Low Energy mesh networks exhibit variable packet latency (200ms - 2500ms per hop) and packet reassembly contention. Real-time continuous streaming over multiple hops is technically unreliable under battery constraints. SUTRAVAQ therefore routes multi-hop voice as high-fidelity, end-to-end encrypted Voice Notes with store-and-forward delivery.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = BrandSlateText
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showTechDisclosureDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = BrandBlack)
                ) {
                    Text("Understood")
                }
            },
            containerColor = BrandSurfaceDark
        )
    }
}

@Composable
fun CallLogItem(
    call: CallLogEntity,
    onCallAgain: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }
    val dateStr = dateFormat.format(Date(call.timestamp))

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = BrandCardDark),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(BrandSurfaceVariantDark),
                contentAlignment = Alignment.Center
            ) {
                val icon = when (call.callType) {
                    "INCOMING" -> Icons.Default.CallReceived
                    "OUTGOING" -> Icons.Default.CallMade
                    else -> Icons.Default.CallMissed
                }
                val tint = when (call.callType) {
                    "MISSED" -> ErrorRed
                    "INCOMING" -> ActiveEmerald
                    else -> CyberCyan
                }
                Icon(icon, contentDescription = null, tint = tint)
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = call.peerName,
                    style = MaterialTheme.typography.titleMedium,
                    color = BrandWhite
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = dateStr,
                        style = MaterialTheme.typography.labelSmall,
                        color = BrandSlateText
                    )
                    if (call.durationSeconds > 0) {
                        Text(
                            text = " • ${call.durationSeconds}s",
                            style = MaterialTheme.typography.labelSmall,
                            color = BrandMutedText
                        )
                    }
                }
            }

            IconButton(onClick = onCallAgain) {
                Icon(Icons.Default.Call, contentDescription = "Call", tint = CyberCyan)
            }
        }
    }
}
