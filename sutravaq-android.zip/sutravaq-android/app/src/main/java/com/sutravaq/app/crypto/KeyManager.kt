package com.sutravaq.app.crypto

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/**
 * Manages device identity keys, secure QR pairing representations, and
 * cached symmetric session keys for connected peer nodes.
 */
class KeyManager(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("sutravaq_crypto_keystore", Context.MODE_PRIVATE)

    // Cache of derived symmetric session keys: peerNodeId -> 32-byte AES key
    private val sessionKeyCache = ConcurrentHashMap<String, ByteArray>()

    var myNodeId: String = ""
        private set
    var myPublicKeyBytes: ByteArray = ByteArray(0)
        private set
    private var myPrivateKeyBytes: ByteArray = ByteArray(0)

    init {
        initializeOrLoadIdentity()
    }

    @Synchronized
    fun initializeOrLoadIdentity() {
        val storedPrivHex = prefs.getString(PREF_PRIVATE_KEY, null)
        val storedPubHex = prefs.getString(PREF_PUBLIC_KEY, null)
        val storedNodeId = prefs.getString(PREF_NODE_ID, null)

        if (storedPrivHex != null && storedPubHex != null && storedNodeId != null) {
            myPrivateKeyBytes = CryptoEngine.hexToBytes(storedPrivHex)
            myPublicKeyBytes = CryptoEngine.hexToBytes(storedPubHex)
            myNodeId = storedNodeId
        } else {
            // Generate fresh identity keypair
            val keyPair = CryptoEngine.generateIdentityKeyPair()
            myPrivateKeyBytes = keyPair.privateKeyBytes
            myPublicKeyBytes = keyPair.publicKeyBytes
            myNodeId = keyPair.nodeId

            prefs.edit()
                .putString(PREF_PRIVATE_KEY, CryptoEngine.bytesToHex(myPrivateKeyBytes))
                .putString(PREF_PUBLIC_KEY, CryptoEngine.bytesToHex(myPublicKeyBytes))
                .putString(PREF_NODE_ID, myNodeId)
                .apply()
        }
    }

    /**
     * Obtains or derives the AES-256 session key for a peer using ECDH.
     */
    fun getOrCreateSessionKey(peerNodeId: String, peerPublicKeyBytes: ByteArray): ByteArray {
        return sessionKeyCache.computeIfAbsent(peerNodeId) {
            CryptoEngine.computeSharedSecret(myPrivateKeyBytes, peerPublicKeyBytes)
        }
    }

    /**
     * Stores peer public key in local secure preferences and updates session key cache.
     */
    fun storePeerPublicKey(peerNodeId: String, peerPublicKeyBytes: ByteArray) {
        prefs.edit()
            .putString("peer_pub_$peerNodeId", CryptoEngine.bytesToHex(peerPublicKeyBytes))
            .apply()
        sessionKeyCache[peerNodeId] = CryptoEngine.computeSharedSecret(myPrivateKeyBytes, peerPublicKeyBytes)
    }

    /**
     * Retrieves stored peer public key if previously paired.
     */
    fun getStoredPeerPublicKey(peerNodeId: String): ByteArray? {
        val hex = prefs.getString("peer_pub_$peerNodeId", null) ?: return null
        return CryptoEngine.hexToBytes(hex)
    }

    /**
     * Generates a safe, non-sensitive QR pairing payload containing only:
     * - Schema identifier ("sutravaq-v1")
     * - Node ID
     * - Display Name
     * - Public Key Hex
     *
     * NEVER includes private keys.
     */
    fun generateQrPairingPayload(displayName: String): String {
        val json = JSONObject().apply {
            put("scheme", "sutravaq-mesh")
            put("v", 1)
            put("id", myNodeId)
            put("name", displayName)
            put("pub", CryptoEngine.bytesToHex(myPublicKeyBytes))
        }
        return json.toString()
    }

    /**
     * Parses and verifies a scanned QR pairing payload.
     * Returns Triple(peerNodeId, peerDisplayName, peerPublicKeyBytes) or null if invalid.
     */
    fun parseQrPairingPayload(qrContent: String): Triple<String, String, ByteArray>? {
        return try {
            val json = JSONObject(qrContent)
            if (json.optString("scheme") != "sutravaq-mesh") return null
            val id = json.getString("id")
            val name = json.getString("name")
            val pubHex = json.getString("pub")
            val pubBytes = CryptoEngine.hexToBytes(pubHex)

            // Verify integrity: Node ID must strictly match SHA-256(PublicKey)
            val derivedId = CryptoEngine.deriveNodeIdFromPublicKey(pubBytes)
            if (!derivedId.equals(id, ignoreCase = true)) {
                return null
            }
            Triple(id, name, pubBytes)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Securely wipes all identity keys and stored peer keys.
     */
    fun resetIdentity(): KeyPairResult {
        sessionKeyCache.clear()
        prefs.edit().clear().apply()
        initializeOrLoadIdentity()
        return KeyPairResult(myPublicKeyBytes, myPrivateKeyBytes, myNodeId)
    }

    companion object {
        private const val PREF_PRIVATE_KEY = "identity_private_key"
        private const val PREF_PUBLIC_KEY = "identity_public_key"
        private const val PREF_NODE_ID = "identity_node_id"
    }
}
