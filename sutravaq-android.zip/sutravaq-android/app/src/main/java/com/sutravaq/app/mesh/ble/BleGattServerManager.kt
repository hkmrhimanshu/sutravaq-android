package com.sutravaq.app.mesh.ble

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.util.Log

/**
 * Manages the local Bluetooth GATT Server for SUTRAVAQ mesh communication.
 * Accepts incoming connections and receives routed mesh packets from peer nodes.
 */
class BleGattServerManager(
    private val context: Context,
    private val bluetoothManager: BluetoothManager?,
    private val onPacketReceived: (packetBytes: ByteArray, sourceDevice: BluetoothDevice) -> Unit
) {
    private var gattServer: BluetoothGattServer? = null

    private val gattServerCallback = object : BluetoothGattServerCallback() {
        override fun onConnectionStateChange(device: BluetoothDevice?, status: Int, newState: Int) {
            super.onConnectionStateChange(device, status, newState)
            Log.d(TAG, "GattServer connection change: device=${device?.address}, status=$status, newState=$newState")
        }

        @SuppressLint("MissingPermission")
        override fun onCharacteristicWriteRequest(
            device: BluetoothDevice?,
            requestId: Int,
            characteristic: BluetoothGattCharacteristic?,
            preparedWrite: Boolean,
            responseNeeded: Boolean,
            offset: Int,
            value: ByteArray?
        ) {
            super.onCharacteristicWriteRequest(device, requestId, characteristic, preparedWrite, responseNeeded, offset, value)

            if (responseNeeded) {
                gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, value)
            }

            if (characteristic?.uuid == BleAdvertiserManager.CHARACTERISTIC_PACKET_UUID && value != null && device != null) {
                onPacketReceived(value, device)
            }
        }

        override fun onMtuChanged(device: BluetoothDevice?, mtu: Int) {
            super.onMtuChanged(device, mtu)
            Log.d(TAG, "GattServer MTU changed: device=${device?.address}, mtu=$mtu")
        }
    }

    @SuppressLint("MissingPermission")
    fun startServer(): Boolean {
        if (bluetoothManager == null) return false

        try {
            gattServer = bluetoothManager.openGattServer(context, gattServerCallback)
            if (gattServer == null) {
                Log.e(TAG, "Unable to open GATT Server.")
                return false
            }

            // Create SUTRAVAQ Mesh Primary Service
            val service = BluetoothGattService(
                BleAdvertiserManager.SERVICE_UUID,
                BluetoothGattService.SERVICE_TYPE_PRIMARY
            )

            // Characteristic for bidirectional packet exchange
            val packetChar = BluetoothGattCharacteristic(
                BleAdvertiserManager.CHARACTERISTIC_PACKET_UUID,
                BluetoothGattCharacteristic.PROPERTY_WRITE or
                        BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE or
                        BluetoothGattCharacteristic.PROPERTY_READ or
                        BluetoothGattCharacteristic.PROPERTY_NOTIFY,
                BluetoothGattCharacteristic.PERMISSION_WRITE or BluetoothGattCharacteristic.PERMISSION_READ
            )

            service.addCharacteristic(packetChar)
            val added = gattServer?.addService(service) ?: false
            Log.d(TAG, "SUTRAVAQ GATT Service added: $added")
            return added
        } catch (e: SecurityException) {
            Log.e(TAG, "Missing Bluetooth permission to open GATT Server", e)
            return false
        }
    }

    @SuppressLint("MissingPermission")
    fun stopServer() {
        try {
            gattServer?.close()
            gattServer = null
            Log.d(TAG, "GATT Server closed.")
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException while closing GATT server", e)
        }
    }

    companion object {
        private const val TAG = "BleGattServerManager"
    }
}
