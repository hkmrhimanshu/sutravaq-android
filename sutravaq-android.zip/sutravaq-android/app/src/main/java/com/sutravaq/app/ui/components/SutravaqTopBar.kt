package com.sutravaq.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sutravaq.app.R
import com.sutravaq.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SutravaqTopBar(
    connectedPeersCount: Int,
    onMenuAction: (String) -> Unit,
    onSearchClick: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }

    // Pulsing mesh beacon animation
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "beacon_alpha"
    )

    TopAppBar(
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Official SUTRAVAQ Logo
                Image(
                    painter = painterResource(id = R.drawable.ic_sutravaq_toolbar),
                    contentDescription = "SUTRAVAQ Official Logo",
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                )

                Column {
                    Text(
                        text = "SUTRAVAQ",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.2.sp
                        ),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(
                                    if (connectedPeersCount > 0) ActiveEmerald.copy(alpha = alpha)
                                    else CyberCyan.copy(alpha = alpha)
                                )
                        )
                        Text(
                            text = if (connectedPeersCount > 0) "$connectedPeersCount Mesh Peers" else "Mesh Ready • Offline",
                            style = MaterialTheme.typography.labelSmall,
                            color = BrandSlateText
                        )
                    }
                }
            }
        },
        actions = {
            IconButton(onClick = onSearchClick) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }

            Box {
                IconButton(onClick = { menuExpanded = true }) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "More options",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    DropdownMenuItem(
                        text = { Text("Settings") },
                        leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null, tint = CyberCyan) },
                        onClick = {
                            menuExpanded = false
                            onMenuAction("settings")
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("My QR Code") },
                        leadingIcon = { Icon(Icons.Default.QrCode, contentDescription = null, tint = CyberCyan) },
                        onClick = {
                            menuExpanded = false
                            onMenuAction("my_qr")
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("QR Scanner") },
                        leadingIcon = { Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = CyberCyan) },
                        onClick = {
                            menuExpanded = false
                            onMenuAction("qr_scanner")
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("My Profile") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = CyberCyan) },
                        onClick = {
                            menuExpanded = false
                            onMenuAction("profile")
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Privacy and Security") },
                        leadingIcon = { Icon(Icons.Default.Security, contentDescription = null, tint = CyberCyan) },
                        onClick = {
                            menuExpanded = false
                            onMenuAction("privacy_security")
                        }
                    )
                    HorizontalDivider(color = BrandBorderDark)
                    DropdownMenuItem(
                        text = { Text("About SUTRAVAQ") },
                        leadingIcon = { Icon(Icons.Default.Info, contentDescription = null, tint = CyberCyan) },
                        onClick = {
                            menuExpanded = false
                            onMenuAction("about")
                        }
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.background
        )
    )
}
