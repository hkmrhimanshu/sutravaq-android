package com.sutravaq.app.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.sutravaq.app.ui.theme.*

sealed class NavTab(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    data object Chats : NavTab("chats", "Chats", Icons.Filled.Chat, Icons.Outlined.Chat)
    data object Online : NavTab("online", "Online", Icons.Filled.Hub, Icons.Outlined.Hub)
    data object Status : NavTab("status", "Status", Icons.Filled.DonutLarge, Icons.Outlined.DonutLarge)
    data object Calls : NavTab("calls", "Calls", Icons.Filled.Call, Icons.Outlined.Call)
}

val ALL_NAV_TABS = listOf(
    NavTab.Chats,
    NavTab.Online,
    NavTab.Status,
    NavTab.Calls
)

@Composable
fun SutravaqBottomBar(
    currentRoute: String,
    unreadChatsCount: Int = 0,
    onlinePeersCount: Int = 0,
    onTabSelected: (NavTab) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        ALL_NAV_TABS.forEach { tab ->
            val isSelected = currentRoute == tab.route

            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(tab) },
                icon = {
                    BadgedBox(
                        badge = {
                            if (tab == NavTab.Chats && unreadChatsCount > 0) {
                                Badge(containerColor = CyberCyan, contentColor = BrandBlack) {
                                    Text(unreadChatsCount.toString())
                                }
                            } else if (tab == NavTab.Online && onlinePeersCount > 0) {
                                Badge(containerColor = ActiveEmerald, contentColor = BrandBlack) {
                                    Text(onlinePeersCount.toString())
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                            contentDescription = tab.title,
                            tint = if (isSelected) CyberCyan else BrandSlateText
                        )
                    }
                },
                label = {
                    Text(
                        text = tab.title,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) CyberCyan else BrandSlateText
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = BrandSurfaceVariantDark
                )
            )
        }
    }
}
