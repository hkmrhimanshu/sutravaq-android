package com.sutravaq.app.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.sutravaq.app.ui.theme.*

sealed class NavTab(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    data object Chats : NavTab("chats", "Chats", Icons.Default.Chat)
    data object Online : NavTab("online", "Online", Icons.Default.Share)
    data object Status : NavTab("status", "Status", Icons.Default.Refresh)
    data object Calls : NavTab("calls", "Calls", Icons.Default.Call)
}

val ALL_NAV_TABS = listOf(
    NavTab.Chats,
    NavTab.Online,
    NavTab.Status,
    NavTab.Calls
)

@Composable
fun SutravaqBottomBar(
    currentRoute: String,
    unreadChatsCount: Int = 0,
    onlinePeersCount: Int = 0,
    onTabSelected: (NavTab) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        ALL_NAV_TABS.forEach { tab ->
            val isSelected = currentRoute == tab.route

            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(tab) },
                icon = {
                    BadgedBox(
                        badge = {
                            if (tab == NavTab.Chats && unreadChatsCount > 0) {
                                Badge(containerColor = CyberCyan, contentColor = BrandBlack) {
                                    Text(unreadChatsCount.toString())
                                }
                            } else if (tab == NavTab.Online && onlinePeersCount > 0) {
                                Badge(containerColor = ActiveEmerald, contentColor = BrandBlack) {
                                    Text(onlinePeersCount.toString())
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = tab.icon,
                            contentDescription = tab.title,
                            tint = if (isSelected) CyberCyan else BrandSlateText
                        )
                    }
                },
                label = {
                    Text(
                        text = tab.title,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) CyberCyan else BrandSlateText
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = BrandSurfaceVariantDark
                )
            )
        }
    }
}
