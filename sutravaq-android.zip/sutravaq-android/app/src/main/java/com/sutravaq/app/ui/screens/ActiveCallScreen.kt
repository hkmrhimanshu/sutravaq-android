package com.sutravaq.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sutravaq.app.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun ActiveCallScreen(
    peerId: String,
    peerName: String,
    isIncoming: Boolean = false,
    onEndCall: (durationSeconds: Int) -> Unit
) {
    var callState by remember { mutableStateOf(if (isIncoming) "INCOMING" else "CONNECTING") }
    var isMuted by remember { mutableStateOf(false) }
    var isSpeakerOn by remember { mutableStateOf(false) }
    var callDurationSeconds by remember { mutableIntStateOf(0) }

    // Pulsing circle animation
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "call_pulse"
    )

    // Simulate auto-connection for outgoing call
    LaunchedEffect(Unit) {
        if (!isIncoming) {
            delay(1500)
            callState = "CONNECTED"
        }
    }

    // Call duration timer
    LaunchedEffect(callState) {
        if (callState == "CONNECTED") {
            while (true) {
                delay(1000)
                callDurationSeconds++
            }
        }
    }

    val minutes = callDurationSeconds / 60
    val seconds = callDurationSeconds % 60
    val timerStr = String.format("%02d:%02d", minutes, seconds)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BrandObsidian)
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Info
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = peerName,
                    style = MaterialTheme.typography.headlineLarge,
                    color = BrandWhite
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = when (callState) {
                        "INCOMING" -> "Incoming Bluetooth Voice Call..."
                        "CONNECTING" -> "Establishing Direct BLE Voice Link..."
                        else -> "Connected • $timerStr"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    color = if (callState == "CONNECTED") ActiveEmerald else CyberCyan
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Direct 1-Hop Bluetooth • No Internet • AES-256 Encrypted",
                    style = MaterialTheme.typography.labelSmall,
                    color = BrandSlateText
                )
            }

            // Animated Center Waveform / Avatar
            Box(
                modifier = Modifier
                    .size(160.dp * (if (callState == "CONNECTED") scale else 1f))
                    .clip(CircleShape)
                    .background(BrandSurfaceVariantDark.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .clip(CircleShape)
                        .background(BrandSurfaceDark),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(64.dp)
                    )
                }
            }

            // Bottom Call Controls
            if (callState == "INCOMING") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    // Reject Button
                    IconButton(
                        onClick = { onEndCall(0) },
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(ErrorRed)
                    ) {
                        Icon(Icons.Default.CallEnd, contentDescription = "Decline", tint = BrandWhite)
                    }

                    // Accept Button
                    IconButton(
                        onClick = { callState = "CONNECTED" },
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(ActiveEmerald)
                    ) {
                        Icon(Icons.Default.Call, contentDescription = "Accept", tint = BrandWhite)
                    }
                }
            } else {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        IconButton(
                            onClick = { isMuted = !isMuted },
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(if (isMuted) CyberCyan else BrandSurfaceVariantDark)
                        ) {
                            Icon(
                                if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                contentDescription = "Mute",
                                tint = if (isMuted) BrandBlack else BrandWhite
                            )
                        }

                        IconButton(
                            onClick = { isSpeakerOn = !isSpeakerOn },
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(if (isSpeakerOn) CyberCyan else BrandSurfaceVariantDark)
                        ) {
                            Icon(
                                if (isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeDown,
                                contentDescription = "Speaker",
                                tint = if (isSpeakerOn) BrandBlack else BrandWhite
                            )
                        }
                    }

                    // End Call Button
                    IconButton(
                        onClick = { onEndCall(callDurationSeconds) },
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(ErrorRed)
                    ) {
                        Icon(Icons.Default.CallEnd, contentDescription = "End Call", tint = BrandWhite)
                    }
                }
            }
        }
    }
}
