package com.sutravaq.app.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sutravaq.app.data.db.entity.ContactEntity
import com.sutravaq.app.ui.theme.*

@Composable
fun OnlineScreen(
    isPublicDiscoveryEnabled: Boolean,
    onTogglePublicDiscovery: (Boolean) -> Unit,
    contacts: List<ContactEntity>,
    onConnectWithId: (sutravaqId: String) -> Unit,
    onStartChat: (peerId: String) -> Unit
) {
    val context = LocalContext.current
    var showPrivateIdDialog by remember { mutableStateOf(false) }
    var inputId by remember { mutableStateOf("") }

    val directNeighbors = remember(contacts) { contacts.filter { it.directHopDistance == 1 } }
    val meshReachable = remember(contacts) { contacts.filter { it.directHopDistance > 1 } }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showPrivateIdDialog = true },
                containerColor = CyberCyan,
                contentColor = BrandBlack,
                icon = { Icon(Icons.Default.PersonAdd, contentDescription = null) },
                text = { Text("Connect by ID") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Public Discovery Consent Banner
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = BrandSurfaceVariantDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Public Mesh Discovery",
                                style = MaterialTheme.typography.titleMedium,
                                color = BrandWhite
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (isPublicDiscoveryEnabled)
                                    "Your display name & ID are discoverable by nearby SUTRAVAQ phones."
                                else
                                    "You are hidden from public scans. Only direct ID pairing will connect.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = BrandSlateText
                            )
                        }
                        Switch(
                            checked = isPublicDiscoveryEnabled,
                            onCheckedChange = onTogglePublicDiscovery,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = BrandBlack,
                                checkedTrackColor = CyberCyan
                            )
                        )
                    }
                }
            }

            // Direct 1-Hop Bluetooth Neighbors Section
            item {
                SectionHeader("Direct Bluetooth Neighbors (${directNeighbors.size})", "1-hop direct BLE range")
            }

            if (directNeighbors.isEmpty()) {
                item {
                    Text(
                        text = "No direct Bluetooth devices found nearby. Ensure Bluetooth is enabled.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = BrandSlateText,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                }
            } else {
                items(directNeighbors, key = { it.userId }) { peer ->
                    PeerDiscoveryCard(peer = peer, onStartChat = onStartChat)
                }
            }

            // Multi-Hop Mesh Reachable Section
            item {
                Spacer(modifier = Modifier.height(8.dp))
                SectionHeader("Mesh Reachable Peers (${meshReachable.size})", "Connected through intermediate relay phones")
            }

            if (meshReachable.isEmpty()) {
                item {
                    Text(
                        text = "No multi-hop relay peers currently discovered across the mesh.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = BrandSlateText,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                }
            } else {
                items(meshReachable, key = { it.userId }) { peer ->
                    PeerDiscoveryCard(peer = peer, onStartChat = onStartChat)
                }
            }
        }
    }

    // Connect via Private ID Dialog
    if (showPrivateIdDialog) {
        AlertDialog(
            onDismissRequest = { showPrivateIdDialog = false },
            title = { Text("Connect by SUTRAVAQ ID", color = BrandWhite) },
            text = {
                Column {
                    Text(
                        text = "Enter a 16 or 32-character SUTRAVAQ ID. A secure pairing request will route across the mesh.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = BrandSlateText
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = inputId,
                        onValueChange = { inputId = it.trim().uppercase() },
                        label = { Text("Peer SUTRAVAQ ID") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = BrandBorderDark,
                            focusedTextColor = BrandWhite,
                            unfocusedTextColor = BrandWhite
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (inputId.isNotBlank()) {
                            onConnectWithId(inputId)
                            showPrivateIdDialog = false
                            Toast.makeText(context, "Pairing request dispatched via mesh", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = BrandBlack)
                ) {
                    Text("Send Request")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPrivateIdDialog = false }) {
                    Text("Cancel", color = BrandSlateText)
                }
            },
            containerColor = BrandSurfaceDark
        )
    }
}

@Composable
fun SectionHeader(title: String, subtitle: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = CyberCyan
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.labelSmall,
            color = BrandSlateText
        )
    }
}

@Composable
fun PeerDiscoveryCard(
    peer: ContactEntity,
    onStartChat: (peerId: String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onStartChat(peer.userId) },
        colors = CardDefaults.cardColors(containerColor = BrandCardDark),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(BrandSurfaceVariantDark),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (peer.directHopDistance == 1) Icons.Default.Bluetooth else Icons.Default.Share,
                    contentDescription = null,
                    tint = if (peer.directHopDistance == 1) ActiveEmerald else CyberCyan
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = peer.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    color = BrandWhite
                )
                Text(
                    text = "ID: ${peer.userId.take(12)}...",
                    style = MaterialTheme.typography.labelSmall,
                    color = BrandSlateText
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (peer.directHopDistance == 1) ActiveEmerald.copy(alpha = 0.2f) else CyberCyan.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (peer.directHopDistance == 1) "1-Hop Direct" else "${peer.directHopDistance} Hops via Relay",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (peer.directHopDistance == 1) ActiveEmerald else CyberCyan
                        )
                    }
                }
            }

            IconButton(onClick = { onStartChat(peer.userId) }) {
                Icon(Icons.Default.Chat, contentDescription = "Chat", tint = CyberCyan)
            }
        }
    }
}
