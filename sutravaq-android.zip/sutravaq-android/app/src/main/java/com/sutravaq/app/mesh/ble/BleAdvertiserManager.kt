package com.sutravaq.app.mesh.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.*
import android.os.ParcelUuid
import android.util.Log
import java.util.UUID

/**
 * Manages Bluetooth Low Energy (BLE) Advertising for SUTRAVAQ mesh beaconing.
 * Dynamically adjusts transmission power and advertising frequency based on
 * battery health and charging status.
 */
class BleAdvertiserManager(
    private val bluetoothAdapter: BluetoothAdapter?,
    private val nodeId: String
) {
    private var advertiser: BluetoothLeAdvertiser? = null
    private var isAdvertising = false

    private val callback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
            isAdvertising = true
            Log.d(TAG, "BLE Mesh Advertising successfully started.")
        }

        override fun onStartFailure(errorCode: Int) {
            isAdvertising = false
            Log.e(TAG, "BLE Mesh Advertising failed with code: $errorCode")
        }
    }

    @SuppressLint("MissingPermission")
    fun startAdvertising(isLowBattery: Boolean = false) {
        if (isAdvertising || bluetoothAdapter == null || !bluetoothAdapter.isEnabled) return

        advertiser = bluetoothAdapter.bluetoothLeAdvertiser
        if (advertiser == null) {
            Log.w(TAG, "BluetoothLeAdvertiser not supported on this device hardware.")
            return
        }

        val mode = if (isLowBattery) {
            AdvertiseSettings.ADVERTISE_MODE_LOW_POWER
        } else {
            AdvertiseSettings.ADVERTISE_MODE_BALANCED
        }

        val txPower = if (isLowBattery) {
            AdvertiseSettings.ADVERTISE_TX_POWER_LOW
        } else {
            AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM
        }

        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(mode)
            .setTxPowerLevel(txPower)
            .setConnectable(true)
            .setTimeout(0) // Continuous
            .build()

        // SUTRAVAQ Service UUID: 0000FA01-0000-1000-8000-00805F9B34FB
        val serviceUuid = ParcelUuid(SERVICE_UUID)

        // Include truncated 4-byte node ID prefix in service data for zero-connect discovery
        val nodePrefix = nodeId.take(8).chunked(2).map { it.toInt(16).toByte() }.toByteArray()

        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .setIncludeTxPowerLevel(false)
            .addServiceUuid(serviceUuid)
            .addServiceData(serviceUuid, nodePrefix)
            .build()

        try {
            advertiser?.startAdvertising(settings, data, callback)
        } catch (e: SecurityException) {
            Log.e(TAG, "Missing Bluetooth permission for advertising", e)
        }
    }

    @SuppressLint("MissingPermission")
    fun stopAdvertising() {
        if (!isAdvertising || advertiser == null) return
        try {
            advertiser?.stopAdvertising(callback)
            isAdvertising = false
            Log.d(TAG, "BLE Mesh Advertising stopped.")
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException while stopping advertising", e)
        }
    }

    companion object {
        private const val TAG = "BleAdvertiserManager"
        val SERVICE_UUID: UUID = UUID.fromString("0000FA01-0000-1000-8000-00805F9B34FB")
        val CHARACTERISTIC_PACKET_UUID: UUID = UUID.fromString("0000FA02-0000-1000-8000-00805F9B34FB")
    }
}
