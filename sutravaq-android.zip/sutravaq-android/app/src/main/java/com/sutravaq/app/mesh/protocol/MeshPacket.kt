package com.sutravaq.app.mesh.protocol

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import java.util.zip.CRC32

/**
 * Binary Packet Framing for SUTRAVAQ Mesh Network.
 *
 * Wire specification:
 * [0..3]   Magic Bytes (0x53, 0x55, 0x54, 0x52 -> "SUTR")
 * [4]      Protocol Version (0x01)
 * [5]      Packet Type (PacketType.code)
 * [6]      Flags (Bitmask: Broadcast=0x01, Encrypted=0x02, AckRequested=0x04, LowBattery=0x08)
 * [7]      TTL / Hop Limit (e.g. 5)
 * [8..9]   Sequence Number (Short)
 * [10..25] Source Node ID (16 bytes)
 * [26..41] Destination Node ID (16 bytes, 0xFF..FF for broadcast)
 * [42..57] Packet ID / UUID (16 bytes for deduplication)
 * [58..59] Payload Length (Short)
 * [60..]   Payload Bytes (N bytes)
 * [End-4]  CRC32 Checksum (4 bytes Int)
 */
data class MeshPacket(
    val version: Byte = PROTOCOL_VERSION,
    val type: PacketType,
    val flags: Byte = 0,
    val ttl: Byte = DEFAULT_TTL,
    val sequenceNumber: Short = 0,
    val sourceNodeId: String,
    val destinationNodeId: String,
    val packetId: String = UUID.randomUUID().toString().replace("-", ""),
    val payload: ByteArray
) {
    val isBroadcast: Boolean
        get() = (flags.toInt() and FLAG_BROADCAST) != 0 || destinationNodeId == BROADCAST_NODE_ID

    val isEncrypted: Boolean
        get() = (flags.toInt() and FLAG_ENCRYPTED) != 0

    val requiresAck: Boolean
        get() = (flags.toInt() and FLAG_ACK_REQUESTED) != 0

    val isLowBattery: Boolean
        get() = (flags.toInt() and FLAG_LOW_BATTERY) != 0

    /**
     * Decrements TTL by 1 for multi-hop relay forwarding.
     * Returns a new copy or null if TTL has expired (packet should be dropped).
     */
    fun createRelayCopy(): MeshPacket? {
        if (ttl <= 1) return null
        return copy(ttl = (ttl - 1).toByte())
    }

    /**
     * Serializes this packet into wire binary format with CRC32 integrity checksum.
     */
    fun toByteArray(): ByteArray {
        val srcBytes = nodeIdToBytes(sourceNodeId)
        val dstBytes = nodeIdToBytes(destinationNodeId)
        val pktIdBytes = packetIdToBytes(packetId)

        val totalHeaderLen = 4 + 1 + 1 + 1 + 1 + 2 + 16 + 16 + 16 + 2 // 60 bytes
        val totalSize = totalHeaderLen + payload.size + 4 // + 4 for CRC32

        val buffer = ByteBuffer.allocate(totalSize).order(ByteOrder.BIG_ENDIAN)
        buffer.put(MAGIC_BYTES)
        buffer.put(version)
        buffer.put(type.code)
        buffer.put(flags)
        buffer.put(ttl)
        buffer.putShort(sequenceNumber)
        buffer.put(srcBytes)
        buffer.put(dstBytes)
        buffer.put(pktIdBytes)
        buffer.putShort(payload.size.toShort())
        buffer.put(payload)

        // Calculate CRC32 over the data preceding the checksum
        val crc = CRC32()
        crc.update(buffer.array(), 0, totalSize - 4)
        val crcValue = crc.value.toInt()
        buffer.putInt(crcValue)

        return buffer.array()
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is MeshPacket) return false
        return version == other.version &&
                type == other.type &&
                flags == other.flags &&
                ttl == other.ttl &&
                sequenceNumber == other.sequenceNumber &&
                sourceNodeId == other.sourceNodeId &&
                destinationNodeId == other.destinationNodeId &&
                packetId == other.packetId &&
                payload.contentEquals(other.payload)
    }

    override fun hashCode(): Int {
        var result = version.toInt()
        result = 31 * result + type.hashCode()
        result = 31 * result + flags.toInt()
        result = 31 * result + ttl.toInt()
        result = 31 * result + sequenceNumber.toInt()
        result = 31 * result + sourceNodeId.hashCode()
        result = 31 * result + destinationNodeId.hashCode()
        result = 31 * result + packetId.hashCode()
        result = 31 * result + payload.contentHashCode()
        return result
    }

    companion object {
        val MAGIC_BYTES = byteArrayOf(0x53, 0x55, 0x54, 0x52) // "SUTR"
        const val PROTOCOL_VERSION: Byte = 0x01
        const val DEFAULT_TTL: Byte = 5
        const val BROADCAST_NODE_ID = "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"

        const val FLAG_BROADCAST: Int = 0x01
        const val FLAG_ENCRYPTED: Int = 0x02
        const val FLAG_ACK_REQUESTED: Int = 0x04
        const val FLAG_LOW_BATTERY: Int = 0x08

        fun fromByteArray(bytes: ByteArray): MeshPacket? {
            if (bytes.size < 64) return null // Minimum packet size with empty payload

            val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)

            // 1. Verify Magic Bytes
            val magic = ByteArray(4)
            buffer.get(magic)
            if (!magic.contentEquals(MAGIC_BYTES)) return null

            val version = buffer.get()
            val typeCode = buffer.get()
            val flags = buffer.get()
            val ttl = buffer.get()
            val sequenceNumber = buffer.short

            val srcBytes = ByteArray(16)
            buffer.get(srcBytes)
            val dstBytes = ByteArray(16)
            buffer.get(dstBytes)
            val pktIdBytes = ByteArray(16)
            buffer.get(pktIdBytes)

            val payloadLength = buffer.short.toInt() and 0xFFFF
            if (buffer.remaining() < payloadLength + 4) return null

            val payload = ByteArray(payloadLength)
            buffer.get(payload)

            val receivedCrc = buffer.int

            // 2. Verify CRC32 Checksum
            val crc = CRC32()
            crc.update(bytes, 0, bytes.size - 4)
            if (crc.value.toInt() != receivedCrc) {
                return null // Corrupted packet, discard
            }

            return MeshPacket(
                version = version,
                type = PacketType.fromCode(typeCode),
                flags = flags,
                ttl = ttl,
                sequenceNumber = sequenceNumber,
                sourceNodeId = bytesToHex(srcBytes),
                destinationNodeId = bytesToHex(dstBytes),
                packetId = bytesToHex(pktIdBytes),
                payload = payload
            )
        }

        private fun nodeIdToBytes(nodeId: String): ByteArray {
            val clean = nodeId.padEnd(32, '0').take(32)
            return hexToBytes(clean)
        }

        private fun packetIdToBytes(packetId: String): ByteArray {
            val clean = packetId.replace("-", "").padEnd(32, '0').take(32)
            return hexToBytes(clean)
        }

        private fun hexToBytes(hex: String): ByteArray {
            val data = ByteArray(16)
            for (i in 0 until 16) {
                val index = i * 2
                data[i] = ((Character.digit(hex[index], 16) shl 4) +
                        Character.digit(hex[index + 1], 16)).toByte()
            }
            return data
        }

        private fun bytesToHex(bytes: ByteArray): String {
            return bytes.joinToString("") { "%02X".format(it) }
        }
    }
}
