package com.sutravaq.app

import com.sutravaq.app.crypto.CryptoEngine
import com.sutravaq.app.mesh.protocol.*
import org.junit.Assert.*
import org.junit.Test
import java.util.UUID

/**
 * Unit Test Suite for SUTRAVAQ Core Engines:
 * 1. Cryptography (NIST P-256 ECDH + AES-256-GCM + Tamper Protection)
 * 2. Mesh Packet Wire Protocol (Framing + Magic Bytes + CRC32)
 * 3. Segmentation and Reassembly (SAR) of media chunks
 * 4. Duplicate Packet Suppression Filter
 * 5. Multi-Hop Metric-Based Routing Table
 */
class SutravaqCoreTestSuite {

    // --- 1. CRYPTO ENGINE TESTS ---

    @Test
    fun testIdentityKeyGenerationAndNodeIdDerivation() {
        val alice = CryptoEngine.generateIdentityKeyPair()
        assertNotNull(alice.publicKeyBytes)
        assertNotNull(alice.privateKeyBytes)
        assertEquals(32, alice.nodeId.length) // 16 bytes = 32 hex chars

        val derivedNodeId = CryptoEngine.deriveNodeIdFromPublicKey(alice.publicKeyBytes)
        assertEquals(alice.nodeId, derivedNodeId)
    }

    @Test
    fun testEcdhKeyAgreementAndAesGcmRoundTrip() {
        // Alice generates keypair
        val alice = CryptoEngine.generateIdentityKeyPair()
        // Bob generates keypair
        val bob = CryptoEngine.generateIdentityKeyPair()

        // Compute ECDH shared secrets
        val aliceSecret = CryptoEngine.computeSharedSecret(alice.privateKeyBytes, bob.publicKeyBytes)
        val bobSecret = CryptoEngine.computeSharedSecret(bob.privateKeyBytes, alice.publicKeyBytes)

        // Verify shared secrets match
        assertArrayEquals("ECDH shared secrets must be identical", aliceSecret, bobSecret)
        assertEquals(32, aliceSecret.size) // 256-bit AES key

        // Alice encrypts plaintext message
        val originalMessage = "SUTRAVAQ: Connecting without Internet via Bluetooth mesh!"
        val plaintextBytes = originalMessage.toByteArray(Charsets.UTF_8)
        val encrypted = CryptoEngine.encryptAesGcm(plaintextBytes, aliceSecret)

        assertFalse(encrypted.ciphertext.contentEquals(plaintextBytes))

        // Bob decrypts message
        val decryptedBytes = CryptoEngine.decryptAesGcm(encrypted, bobSecret)
        val decryptedMessage = String(decryptedBytes, Charsets.UTF_8)

        assertEquals(originalMessage, decryptedMessage)
    }

    @Test(expected = Exception::class)
    fun testAesGcmTamperDetection() {
        val alice = CryptoEngine.generateIdentityKeyPair()
        val bob = CryptoEngine.generateIdentityKeyPair()
        val secret = CryptoEngine.computeSharedSecret(alice.privateKeyBytes, bob.publicKeyBytes)

        val plaintext = "Tamper check message".toByteArray(Charsets.UTF_8)
        val encrypted = CryptoEngine.encryptAesGcm(plaintext, secret)

        // Tamper with one byte of the ciphertext
        val tamperedCiphertext = encrypted.ciphertext.clone()
        tamperedCiphertext[tamperedCiphertext.size / 2] = (tamperedCiphertext[tamperedCiphertext.size / 2].toInt() xor 0xFF).toByte()

        val tamperedPayload = CryptoEngine.EncryptedPayload(encrypted.iv, tamperedCiphertext)
        // Must throw AEADBadTagException or security exception
        CryptoEngine.decryptAesGcm(tamperedPayload, secret)
    }

    // --- 2. MESH PACKET WIRE PROTOCOL TESTS ---

    @Test
    fun testPacketSerializationAndCrcVerification() {
        val srcNode = "A1B2C3D4E5F60718293A4B5C6D7E8F90"
        val dstNode = "11223344556677889900AABBCCDDEEFF"
        val payload = "Hello SUTRAVAQ Mesh".toByteArray(Charsets.UTF_8)

        val packet = MeshPacket(
            type = PacketType.CHAT_MSG,
            flags = MeshPacket.FLAG_ENCRYPTED.toByte(),
            ttl = 5,
            sequenceNumber = 42,
            sourceNodeId = srcNode,
            destinationNodeId = dstNode,
            payload = payload
        )

        val wireBytes = packet.toByteArray()
        assertNotNull(wireBytes)
        assertTrue(wireBytes.size >= 64 + payload.size)

        // Deserialize
        val deserialized = MeshPacket.fromByteArray(wireBytes)
        assertNotNull("Deserialized packet must not be null", deserialized)
        assertEquals(packet.type, deserialized!!.type)
        assertEquals(packet.ttl, deserialized.ttl)
        assertEquals(packet.sequenceNumber, deserialized.sequenceNumber)
        assertEquals(packet.sourceNodeId, deserialized.sourceNodeId)
        assertEquals(packet.destinationNodeId, deserialized.destinationNodeId)
        assertArrayEquals(packet.payload, deserialized.payload)
    }

    @Test
    fun testPacketTtlDecrement() {
        val packet = MeshPacket(
            type = PacketType.CHAT_MSG,
            ttl = 3,
            sourceNodeId = "AAAABBBBCCCCDDDDAAAABBBBCCCCDDDD",
            destinationNodeId = "11112222333344441111222233334444",
            payload = byteArrayOf(1, 2, 3)
        )

        val hop1 = packet.createRelayCopy()
        assertNotNull(hop1)
        assertEquals(2, hop1!!.ttl.toInt())

        val hop2 = hop1.createRelayCopy()
        assertNotNull(hop2)
        assertEquals(1, hop2!!.ttl.toInt())

        val hop3 = hop2.createRelayCopy()
        assertNull("Packet with TTL=1 must be dropped on next hop", hop3)
    }

    // --- 3. FRAGMENTATION & REASSEMBLY (SAR) TESTS ---

    @Test
    fun testMediaFragmentationAndReassembly() {
        val transferId = UUID.randomUUID().toString()
        // Create 2 KB synthetic photo payload
        val originalMedia = ByteArray(2048) { (it % 256).toByte() }

        // Split into chunks of 300 bytes
        val chunkByteArrays = FragmentationEngine.fragmentPayload(transferId, originalMedia, chunkSize = 300)
        assertEquals(7, chunkByteArrays.size) // ceil(2048 / 300) = 7 chunks

        var reassembled: ByteArray? = null
        // Ingest chunks out of order to simulate mesh propagation jitter
        val outOfOrderIndices = listOf(3, 1, 6, 0, 4, 2, 5)

        for (idx in outOfOrderIndices) {
            val result = FragmentationEngine.ingestChunk(chunkByteArrays[idx])
            assertNotNull(result)
            if (result!!.second != null) {
                reassembled = result.second
            }
        }

        assertNotNull("Reassembled media must not be null", reassembled)
        assertEquals(originalMedia.size, reassembled!!.size)
        assertArrayEquals("Reassembled media must match original bytes", originalMedia, reassembled)
    }

    // --- 4. DUPLICATE FILTER TESTS ---

    @Test
    fun testDuplicateFilterSuppression() {
        val filter = DuplicateFilter(maxCapacity = 100, expirationMs = 5000L)
        val packetId = "PKT_998877665544332211"

        // First arrival: not duplicate
        assertFalse(filter.isDuplicateAndMark(packetId))

        // Second arrival: duplicate!
        assertTrue(filter.isDuplicateAndMark(packetId))

        // Different packet: not duplicate
        assertFalse(filter.isDuplicateAndMark("PKT_DIFFERENT_12345"))
    }

    // --- 5. ROUTING TABLE TESTS ---

    @Test
    fun testRoutingTableMetricSelection() {
        val myId = "MY_NODE_000000000000000000000000"
        val targetId = "TARGET_NODE_FFFFFFFFFFFFFFFFFFFF"
        val table = RoutingTable(myId)

        // Initially unknown
        assertNull(table.getNextHop(targetId))

        // Learned 3-hop route via MAC 00:11:22:33:44:55
        table.updateRoute(targetId, "00:11:22:33:44:55", hopCount = 3, rssi = -75)
        assertEquals("00:11:22:33:44:55", table.getNextHop(targetId))

        // Learned better 1-hop direct route via MAC AA:BB:CC:DD:EE:FF
        table.updateRoute(targetId, "AA:BB:CC:DD:EE:FF", hopCount = 1, rssi = -60)
        assertEquals("AA:BB:CC:DD:EE:FF", table.getNextHop(targetId))

        // Learned worse 4-hop route: should be rejected
        table.updateRoute(targetId, "11:22:33:44:55:66", hopCount = 4, rssi = -50)
        assertEquals("AA:BB:CC:DD:EE:FF", table.getNextHop(targetId))
    }
}
