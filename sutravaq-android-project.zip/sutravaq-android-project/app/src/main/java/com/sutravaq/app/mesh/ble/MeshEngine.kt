package com.sutravaq.app.mesh.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.util.Log
import com.sutravaq.app.crypto.CryptoEngine
import com.sutravaq.app.crypto.KeyManager
import com.sutravaq.app.data.db.SutravaqDatabase
import com.sutravaq.app.data.db.entity.ConversationEntity
import com.sutravaq.app.data.db.entity.MessageEntity
import com.sutravaq.app.data.db.entity.QueuedPacketEntity
import com.sutravaq.app.mesh.protocol.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Central SUTRAVAQ Mesh Engine.
 *
 * Coordinates:
 * - Multi-hop packet routing and forwarding.
 * - Store-and-forward persistent queueing.
 * - Duplicate suppression and broadcast loop prevention.
 * - Battery-aware routing (adapts duty-cycle and limits relay when battery < 15%).
 * - End-to-end payload decryption and verification.
 */
class MeshEngine(
    private val context: Context,
    private val keyManager: KeyManager,
    private val database: SutravaqDatabase,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) {
    private val bluetoothManager: BluetoothManager? =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    val routingTable = RoutingTable(keyManager.myNodeId)
    val duplicateFilter = DuplicateFilter()

    private val advertiserManager = BleAdvertiserManager(bluetoothAdapter, keyManager.myNodeId)
    private var scannerManager: BleScannerManager? = null
    private var gattServerManager: BleGattServerManager? = null
    private val gattClientManager = BleGattClientManager(context, scope)

    // Maps Bluetooth MAC address to BluetoothDevice
    private val discoveredDevices = ConcurrentHashMap<String, BluetoothDevice>()

    // Network stats reactive state
    private val _connectedPeersCount = MutableStateFlow(0)
    val connectedPeersCount: StateFlow<Int> = _connectedPeersCount.asStateFlow()

    private val _isRelayActive = MutableStateFlow(true)
    val isRelayActive: StateFlow<Boolean> = _isRelayActive.asStateFlow()

    private var isRunning = false

    init {
        scannerManager = BleScannerManager(bluetoothAdapter) { device, rssi, nodePrefix ->
            handlePeerDiscovered(device, rssi, nodePrefix)
        }
        gattServerManager = BleGattServerManager(context, bluetoothManager) { packetBytes, sourceDevice ->
            handleIncomingPacketBytes(packetBytes, sourceDevice)
        }
    }

    @Synchronized
    fun start() {
        if (isRunning) return
        isRunning = true

        val isLowBattery = checkIsLowBattery()
        advertiserManager.startAdvertising(isLowBattery)
        scannerManager?.startScanning(lowLatency = false)
        gattServerManager?.startServer()

        startPeriodicHousekeeping()
        Log.i(TAG, "SUTRAVAQ Mesh Engine started for node: ${keyManager.myNodeId}")
    }

    @Synchronized
    fun stop() {
        if (!isRunning) return
        isRunning = false

        advertiserManager.stopAdvertising()
        scannerManager?.stopScanning()
        gattServerManager?.stopServer()
        gattClientManager.disconnectAll()

        Log.i(TAG, "SUTRAVAQ Mesh Engine stopped.")
    }

    /**
     * Sends an end-to-end encrypted chat message to a destination node.
     */
    fun sendChatMessage(
        conversationId: String,
        recipientNodeId: String,
        content: String,
        mediaType: String = "TEXT",
        replyToMessageId: String? = null
    ) {
        scope.launch {
            val messageId = UUID.randomUUID().toString()
            val now = System.currentTimeMillis()

            // 1. Save local pending message in Room
            val localMessage = MessageEntity(
                messageId = messageId,
                conversationId = conversationId,
                senderId = keyManager.myNodeId,
                recipientId = recipientNodeId,
                content = content,
                mediaType = mediaType,
                timestamp = now,
                status = "TRANSMITTING_MESH",
                isFromMe = true,
                replyToMessageId = replyToMessageId
            )
            database.messageDao().insertMessage(localMessage)

            // Update conversation record
            database.conversationDao().insertOrUpdate(
                ConversationEntity(
                    peerId = conversationId,
                    peerDisplayName = conversationId.take(8),
                    lastMessageText = content,
                    lastMessageTimestamp = now,
                    lastMessageStatus = "TRANSMITTING_MESH"
                )
            )

            // 2. Encrypt payload with peer's public key
            val peerPubKey = keyManager.getStoredPeerPublicKey(recipientNodeId)
            val encryptedBytes: ByteArray

            if (peerPubKey != null) {
                val sessionKey = keyManager.getOrCreateSessionKey(recipientNodeId, peerPubKey)
                val payloadJson = JSONObject().apply {
                    put("msgId", messageId)
                    put("type", mediaType)
                    put("content", content)
                    put("ts", now)
                    put("replyTo", replyToMessageId ?: "")
                }
                val encrypted = CryptoEngine.encryptAesGcm(
                    payloadJson.toString().toByteArray(Charsets.UTF_8),
                    sessionKey
                )
                encryptedBytes = encrypted.toCombinedBytes()
            } else {
                // If peer public key is not yet known, send cleartext JSON (or pairing payload)
                val payloadJson = JSONObject().apply {
                    put("msgId", messageId)
                    put("type", mediaType)
                    put("content", content)
                    put("ts", now)
                    put("replyTo", replyToMessageId ?: "")
                }
                encryptedBytes = payloadJson.toString().toByteArray(Charsets.UTF_8)
            }

            // 3. Construct Mesh Packet
            val flags = (if (peerPubKey != null) MeshPacket.FLAG_ENCRYPTED else 0) or
                    MeshPacket.FLAG_ACK_REQUESTED
            val packet = MeshPacket(
                type = PacketType.CHAT_MSG,
                flags = flags.toByte(),
                ttl = MeshPacket.DEFAULT_TTL,
                sourceNodeId = keyManager.myNodeId,
                destinationNodeId = recipientNodeId,
                payload = encryptedBytes
            )

            // 4. Route or Queue
            routeOrQueuePacket(packet)
        }
    }

    /**
     * Broadcasts an ephemeral 24-hour status update across the mesh.
     */
    fun broadcastStatus(statusId: String, text: String, mediaType: String, privacyTier: String) {
        scope.launch {
            val now = System.currentTimeMillis()
            val json = JSONObject().apply {
                put("statusId", statusId)
                put("authorId", keyManager.myNodeId)
                put("text", text)
                put("type", mediaType)
                put("privacy", privacyTier)
                put("ts", now)
                put("exp", now + 24 * 60 * 60 * 1000L)
            }

            val packet = MeshPacket(
                type = PacketType.STATUS_UPDATE,
                flags = MeshPacket.FLAG_BROADCAST.toByte(),
                ttl = MeshPacket.DEFAULT_TTL,
                sourceNodeId = keyManager.myNodeId,
                destinationNodeId = MeshPacket.BROADCAST_NODE_ID,
                payload = json.toString().toByteArray(Charsets.UTF_8)
            )

            routeOrQueuePacket(packet)
        }
    }

    /**
     * Transmits raw mesh packet to next hop, or broadcasts to all neighbors if broadcast,
     * or queues if no path currently exists (store and forward).
     */
    fun routeOrQueuePacket(packet: MeshPacket) {
        scope.launch {
            val packetBytes = packet.toByteArray()

            if (packet.isBroadcast) {
                // Broadcast to all active direct neighbors
                for (device in discoveredDevices.values) {
                    gattClientManager.sendPacket(device, packetBytes) { }
                }
                return@launch
            }

            val nextHop = routingTable.getNextHop(packet.destinationNodeId)
            val device = nextHop?.let { discoveredDevices[it] }

            if (device != null) {
                gattClientManager.sendPacket(device, packetBytes) { success ->
                    if (!success) {
                        queuePacketForLater(packet)
                    }
                }
            } else {
                // Node unreachable right now: store and forward
                queuePacketForLater(packet)
            }
        }
    }

    private suspend fun queuePacketForLater(packet: MeshPacket) {
        database.queuedPacketDao().enqueue(
            QueuedPacketEntity(
                packetId = packet.packetId,
                destinationId = packet.destinationNodeId,
                rawPacketBytes = packet.toByteArray(),
                ttl = packet.ttl.toInt()
            )
        )
        Log.d(TAG, "Packet ${packet.packetId} enqueued for store-and-forward relay.")
    }

    private fun handlePeerDiscovered(device: BluetoothDevice, rssi: Int, nodePrefix: String?) {
        val address = device.address
        discoveredDevices[address] = device

        // Update routing table with 1-hop neighbor
        val targetId = nodePrefix ?: address.replace(":", "")
        routingTable.updateRoute(
            destinationNodeId = targetId,
            nextHopAddress = address,
            hopCount = 1,
            rssi = rssi,
            isLowBattery = checkIsLowBattery()
        )

        _connectedPeersCount.value = routingTable.getDirectNeighbors().size

        // Drain store-and-forward queue for newly reachable destinations
        scope.launch {
            val queued = database.queuedPacketDao().getPendingPackets(20)
            for (item in queued) {
                val parsed = MeshPacket.fromByteArray(item.rawPacketBytes)
                if (parsed != null && (parsed.destinationNodeId == targetId || parsed.isBroadcast)) {
                    gattClientManager.sendPacket(device, item.rawPacketBytes) { success ->
                        if (success) {
                            scope.launch { database.queuedPacketDao().dequeue(item.packetId) }
                        }
                    }
                }
            }
        }
    }

    private fun handleIncomingPacketBytes(packetBytes: ByteArray, sourceDevice: BluetoothDevice) {
        val packet = MeshPacket.fromByteArray(packetBytes) ?: return

        // 1. Duplicate packet suppression
        if (duplicateFilter.isDuplicateAndMark(packet.packetId)) {
            return
        }

        // 2. Update reverse route to sender
        routingTable.updateRoute(
            destinationNodeId = packet.sourceNodeId,
            nextHopAddress = sourceDevice.address,
            hopCount = 1, // Received directly from this device
            rssi = -60,
            isLowBattery = packet.isLowBattery
        )

        // 3. Check if packet is addressed to ME or is BROADCAST
        val isForMe = packet.destinationNodeId.equals(keyManager.myNodeId, ignoreCase = true)
        val isBroadcast = packet.isBroadcast

        if (isForMe || isBroadcast) {
            processPacketForMe(packet)
        }

        // 4. Relay packet if not solely addressed to me and TTL allows
        if (!isForMe && _isRelayActive.value) {
            val relayCopy = packet.createRelayCopy()
            if (relayCopy != null) {
                // Battery-aware relay check
                if (checkIsLowBattery() && packet.type == PacketType.MEDIA_CHUNK) {
                    Log.d(TAG, "Dropping media chunk relay to conserve critical battery.")
                } else {
                    routeOrQueuePacket(relayCopy)
                }
            }
        }
    }

    private fun processPacketForMe(packet: MeshPacket) {
        scope.launch {
            when (packet.type) {
                PacketType.CHAT_MSG -> {
                    handleIncomingChatMessage(packet)
                }
                PacketType.ACK -> {
                    handleIncomingAck(packet)
                }
                PacketType.STATUS_UPDATE -> {
                    handleIncomingStatus(packet)
                }
                PacketType.HELLO -> {
                    // Handled beacon
                }
                else -> {
                    Log.d(TAG, "Unhandled packet type: ${packet.type}")
                }
            }
        }
    }

    private suspend fun handleIncomingChatMessage(packet: MeshPacket) {
        val plaintext: String = try {
            if (packet.isEncrypted) {
                val peerPubKey = keyManager.getStoredPeerPublicKey(packet.sourceNodeId)
                if (peerPubKey != null) {
                    val sessionKey = keyManager.getOrCreateSessionKey(packet.sourceNodeId, peerPubKey)
                    val encPayload = CryptoEngine.EncryptedPayload.fromCombinedBytes(packet.payload)
                    val decrypted = CryptoEngine.decryptAesGcm(encPayload, sessionKey)
                    String(decrypted, Charsets.UTF_8)
                } else {
                    String(packet.payload, Charsets.UTF_8)
                }
            } else {
                String(packet.payload, Charsets.UTF_8)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to decrypt chat message from ${packet.sourceNodeId}", e)
            return
        }

        val json = JSONObject(plaintext)
        val messageId = json.optString("msgId", packet.packetId)
        val content = json.optString("content", "")
        val mediaType = json.optString("type", "TEXT")
        val timestamp = json.optLong("ts", System.currentTimeMillis())
        val replyTo = json.optString("replyTo", null)

        val message = MessageEntity(
            messageId = messageId,
            conversationId = packet.sourceNodeId,
            senderId = packet.sourceNodeId,
            recipientId = keyManager.myNodeId,
            content = content,
            mediaType = mediaType,
            timestamp = timestamp,
            status = "DELIVERED",
            isFromMe = false,
            replyToMessageId = replyTo
        )
        database.messageDao().insertMessage(message)

        // Update conversation summary
        database.conversationDao().insertOrUpdate(
            ConversationEntity(
                peerId = packet.sourceNodeId,
                peerDisplayName = packet.sourceNodeId.take(8),
                lastMessageText = content,
                lastMessageTimestamp = timestamp,
                unreadCount = 1,
                lastMessageStatus = "DELIVERED"
            )
        )

        // Send ACK back if requested
        if (packet.requiresAck) {
            val ackPacket = MeshPacket(
                type = PacketType.ACK,
                ttl = MeshPacket.DEFAULT_TTL,
                sourceNodeId = keyManager.myNodeId,
                destinationNodeId = packet.sourceNodeId,
                payload = messageId.toByteArray(Charsets.UTF_8)
            )
            routeOrQueuePacket(ackPacket)
        }
    }

    private suspend fun handleIncomingAck(packet: MeshPacket) {
        val ackedMsgId = String(packet.payload, Charsets.UTF_8)
        database.messageDao().updateMessageStatus(ackedMsgId, "DELIVERED")
    }

    private suspend fun handleIncomingStatus(packet: MeshPacket) {
        try {
            val json = JSONObject(String(packet.payload, Charsets.UTF_8))
            val statusId = json.getString("statusId")
            val authorId = json.getString("authorId")
            val text = json.getString("text")
            val mediaType = json.getString("type")
            val privacy = json.getString("privacy")
            val timestamp = json.getLong("ts")
            val expiresAt = json.getLong("exp")

            val statusEntity = com.sutravaq.app.data.db.entity.StatusEntity(
                statusId = statusId,
                authorId = authorId,
                authorName = authorId.take(8),
                mediaType = mediaType,
                contentText = text,
                timestamp = timestamp,
                expiresAt = expiresAt,
                privacyTier = privacy,
                isFromMe = false
            )
            database.statusDao().insertStatus(statusEntity)
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing incoming status update", e)
        }
    }

    private fun checkIsLowBattery(): Boolean {
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        if (level > 0 && scale > 0) {
            val pct = (level * 100) / scale
            return (pct < 15) && !isCharging
        }
        return false
    }

    private fun startPeriodicHousekeeping() {
        scope.launch {
            while (isRunning) {
                delay(60_000L) // Every 1 minute
                routingTable.pruneStaleRoutes()
                FragmentationEngine.pruneExpired()
                database.statusDao().purgeExpired()
                database.queuedPacketDao().pruneFailed()
                _connectedPeersCount.value = routingTable.getDirectNeighbors().size
            }
        }
    }

    companion object {
        private const val TAG = "MeshEngine"
    }
}
