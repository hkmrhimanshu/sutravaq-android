package com.sutravaq.app.data.db.dao

import androidx.room.*
import com.sutravaq.app.data.db.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {
    @Query(\"SELECT * FROM conversations ORDER BY isPinned DESC, lastMessageTimestamp DESC\")
    fun getAllConversations(): Flow<List<ConversationEntity>>

    @Query(\"SELECT * FROM conversations WHERE peerId = :peerId\")
    suspend fun getConversation(peerId: String): ConversationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(conversation: ConversationEntity)

    @Query(\"UPDATE conversations SET unreadCount = 0 WHERE peerId = :peerId\")
    suspend fun markAsRead(peerId: String)

    @Query(\"UPDATE conversations SET isBlocked = :blocked WHERE peerId = :peerId\")
    suspend fun setBlocked(peerId: String, blocked: Boolean)

    @Query(\"DELETE FROM conversations WHERE peerId = :peerId\")
    suspend fun delete(peerId: String)
}

@Dao
interface MessageDao {
    @Query(\"SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp ASC\")
    fun getMessagesForConversation(conversationId: String): Flow<List<MessageEntity>>

    @Query(\"SELECT * FROM messages WHERE messageId = :messageId\")
    suspend fun getMessageById(messageId: String): MessageEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity)

    @Query(\"UPDATE messages SET status = :status WHERE messageId = :messageId\")
    suspend fun updateMessageStatus(messageId: String, status: String)

    @Query(\"UPDATE messages SET transferProgress = :progress WHERE messageId = :messageId\")
    suspend fun updateTransferProgress(messageId: String, progress: Float)

    @Query(\"DELETE FROM messages WHERE messageId = :messageId\")
    suspend fun deleteMessage(messageId: String)

    @Query(\"DELETE FROM messages WHERE conversationId = :conversationId\")
    suspend fun clearConversation(conversationId: String)
}

@Dao
interface ContactDao {
    @Query(\"SELECT * FROM contacts WHERE isBlocked = 0 ORDER BY displayName ASC\")
    fun getAllContacts(): Flow<List<ContactEntity>>

    @Query(\"SELECT * FROM contacts WHERE isNearby = 1 AND isBlocked = 0 ORDER BY directHopDistance ASC, lastSeenTimestamp DESC\")
    fun getNearbyDiscoverableContacts(): Flow<List<ContactEntity>>

    @Query(\"SELECT * FROM contacts WHERE isBlocked = 1\")
    fun getBlockedContacts(): Flow<List<ContactEntity>>

    @Query(\"SELECT * FROM contacts WHERE userId = :userId\")
    suspend fun getContactById(userId: String): ContactEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(contact: ContactEntity)

    @Query(\"UPDATE contacts SET isBlocked = :blocked WHERE userId = :userId\")
    suspend fun setBlocked(userId: String, blocked: Boolean)

    @Query(\"UPDATE contacts SET trustStatus = :trustStatus WHERE userId = :userId\")
    suspend fun setTrustStatus(userId: String, trustStatus: String)

    @Query(\"DELETE FROM contacts WHERE userId = :userId\")
    suspend fun delete(userId: String)
}

@Dao
interface StatusDao {
    @Query(\"SELECT * FROM statuses WHERE expiresAt > :now ORDER BY timestamp DESC\")
    fun getActiveStatuses(now: Long = System.currentTimeMillis()): Flow<List<StatusEntity>>

    @Query(\"SELECT * FROM statuses WHERE authorId = :authorId AND expiresAt > :now\")
    fun getMyStatuses(authorId: String, now: Long = System.currentTimeMillis()): Flow<List<StatusEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStatus(status: StatusEntity)

    @Query(\"UPDATE statuses SET viewCount = viewCount + 1, isViewedByMe = 1 WHERE statusId = :statusId\")
    suspend fun markStatusViewed(statusId: String)

    @Query(\"DELETE FROM statuses WHERE statusId = :statusId\")
    suspend fun deleteStatus(statusId: String)

    @Query(\"DELETE FROM statuses WHERE expiresAt <= :now\")
    suspend fun purgeExpired(now: Long = System.currentTimeMillis())
}

@Dao
interface CallLogDao {
    @Query(\"SELECT * FROM call_logs ORDER BY timestamp DESC\")
    fun getAllCallLogs(): Flow<List<CallLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCallLog(callLog: CallLogEntity)

    @Query(\"DELETE FROM call_logs WHERE callId = :callId\")
    suspend fun deleteCallLog(callId: String)

    @Query(\"DELETE FROM call_logs\")
    suspend fun clearAllCallLogs()
}

@Dao
interface QueuedPacketDao {
    @Query(\"SELECT * FROM queued_packets ORDER BY priority DESC, createdAt ASC LIMIT :limit\")
    suspend fun getPendingPackets(limit: Int = 50): List<QueuedPacketEntity>

    @Query(\"SELECT * FROM queued_packets WHERE destinationId = :destinationId OR destinationId = 'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'\")
    suspend fun getPacketsForDestination(destinationId: String): List<QueuedPacketEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueue(packet: QueuedPacketEntity)

    @Query(\"DELETE FROM queued_packets WHERE packetId = :packetId\")
    suspend fun dequeue(packetId: String)

    @Query(\"UPDATE queued_packets SET retryCount = retryCount + 1 WHERE packetId = :packetId\")
    suspend fun incrementRetry(packetId: String)

    @Query(\"DELETE FROM queued_packets WHERE retryCount > :maxRetries OR (createdAt + :maxAgeMs) < :now\")
    suspend fun pruneFailed(
        maxRetries: Int = 10,
        maxAgeMs: Long = 86400000L,
        now: Long = System.currentTimeMillis()
    )
}
